function abrir_carpeta(id_nodo)
{

    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/abrir_carpeta', //the method in controller
        data: 'id_nodo=' + id_nodo, // #nodo as argument
        success: function (resp) { // after processed, the body is replaced by the new one
            $('#ad_tbody').html(resp);
        }
    });
}
function up()
{
    actual = $('#nodo_actual').val();	// actual node is stored into input hidden element
    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/up', //the method in controller
        data: 'actual=' + actual, // #nodo as argument
        success: function (resp) { // after processed, the body is replaced by the new one
            $('#ad_tbody').html(resp);
        }
    });
}
function new_folder()
{
    $('#new_folder_container').show();
    nombre = $('#nombre_carpeta').focus();
}
function enviar_carpeta()
{
    $('#new_folder_container').hide();
    actual = $('#nodo_actual').val();	// actual node is stored into input hidden element
    nombre = $('#nombre_carpeta').val();
    if (nombre == '')
        return;
    $('#nombre_carpeta').val('');		// erase input contents for te next time
    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/new_folder', //the method in controller
        data: 'actual=' + actual + '&nombre_carpeta=' + nombre, // #nodo as argument
        success: function (resp) { // after processed, the body is replaced by the new one
            $('#ad_tbody').html(resp);
        }
    });
}
function file_upload()
{
    actual = $('#nodo_actual').val()
    $('#current_folder').val(actual);
    //$('#file_upload_container').show();
    $('#file_upl').trigger('click');
}
function image_upload()
{
    actual = $('#nodo_actual').val()
    $('#img_current_folder').val(actual);
    //$('#file_upload_container').show();
    $('#imageUpload').trigger('click');
}
function file_upload_submitfunction()
{
    actual = $('#nodo_actual').val();

    $('#file_upload_submit').trigger('click');
}
function image_upload_submitfunction()
{
    actual = $('#nodo_actual').val();

    $('#image_upload_submit').trigger('click');
}
function chg_empresa(id)
{
    $checkbox = $('#E' + id);    // tenemos el checkbox identificado

    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/chg_empresa', //the method in controller
        data: 'id=' + id + '&chk=' + $checkbox.is(':checked'), // #nodo as argument
    });
}
function chg_trabajador(id)
{
    $checkbox = $('#T' + id);    // tenemos el checkbox identificado

    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/chg_trabajador', //the method in controller
        data: 'id=' + id + '&chk=' + $checkbox.is(':checked'), // #nodo as argument
    });
}
function ver_fichero(id)
{
    window.location = '/pofecam/ad_c/verfichero/' + id, '';
}
function send_by_email(id)
{

    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/send_mail', //the method in controller
        data: 'id=' + id, // #nodo as argument
    });
    alert('El fichero ha sido enviado a su cuenta de correo eléctrico.');
}
function borrar(id_nodo)
{
    actual = $('#nodo_actual').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/ad_c/delete', //the method in controller
        data: 'actual=' + actual + '&id_nodo=' + id_nodo, // #nodo as argument
        success: function (resp) { // after processed, the body is replaced by the new one
            $('#ad_tbody').html(resp);
        }
    });
}
function nodisponible()
{
    alert('El fichero especificado no esta disponible. Probablemente aún no se ha escaneado.')
}
function barcode()
{
    actual = $('#nodo_actual').val();
    $('#id_nodo_actual').val(actual);
    $('#barcode').css('display', 'block');
    $('#barcodename').focus();
}