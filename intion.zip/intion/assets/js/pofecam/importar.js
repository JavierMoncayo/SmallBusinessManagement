$(function () // on document load
{
    $(".drop_empresa").droppable({
        accept: ".centro",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function (event, ui) {
            i_centro(ui.draggable.attr('id_centro'), $(this).attr('id_empresa'))

        }
    });
    $(".drop_centro").droppable({
        accept: ".area",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function (event, ui) {
            i_area(ui.draggable.attr('id_area'), $(this).attr('id_centro'))

        }
    });

    $(".drop_area").droppable({
        accept: ".puesto",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function (event, ui) {

            i_puesto(ui.draggable.attr('id_puesto'), $(this).attr('id_area'))
        }
    });
    $(".drop_puesto").droppable({
        accept: ".mpuesto",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function (event, ui) {

            m_puesto(ui.draggable.attr('id_puesto'), $(this).attr('id_puesto'))
        }
    });
    $(".drop_marea").droppable({
        accept: ".marea",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function (event, ui) {

            m_area(ui.draggable.attr('id_area'), $(this).attr('id_area'))
        }
    });

    $(".centro").draggable();
    $(".area").draggable();
    $(".marea").draggable();
    $(".puesto").draggable();
    $(".mpuesto").draggable();
    emp2 = $('#empresa2').val();
    if (emp2 == 0)
        seleccionar_empresa();
    else
    {
        $('#empresas').hide();
    }
});
function seleccionar_empresa()
{
    emp2 = $('#empresa2').val('0');
    jt_set();  // set a jtables element for emp. selection
    $('#empresas').jtable('load');
    $('#buscar').focus();
}
function jt_set()
{
    base = '/pofecam/index.php/importar_ajax/';
    $('#empresas').show();
    $('#organigrama2').hide();
    $('#empresas').jtable({
        title: 'Lista de empresas:',
        paging: true, //Enable paging
        pageSize: 15, //Set page size (default: 15)
        pageList: 'minimal', // set the pagination buttons to tiny format
        sorting: false, //Disable sorting
        actions: {
            listAction: base + 'ldata', // recover tasks list
        },
        fields: {
            id: {
                key: true,
                create: false,
                edit: false,
                list: false
            },
            nombre: {
                title: 'Razón Social',
                create: false,
                edit: false,
                width: '40%',
                list: true
            },
            poblacion: {
                title: 'Poblacion',
                edit: false,
                create: false,
                width: '10%',
                list: true
            }
        },
        // set up spanish localization
        messages: {
            serverCommunicationError: 'Ocurrió un error en la comunicación con el servidor.',
            loadingMessage: 'Cargando registros...',
            noDataAvailable: 'No hay datos disponibles!',
            addNewRecord: 'Crear nuevo registro',
            editRecord: 'Editar registro',
            areYouSure: '¿Está seguro?',
            deleteConfirmation: 'El registro será eliminado. ¿Está seguro?',
            save: 'Guardar',
            saving: 'Guardando',
            cancel: 'Cancelar',
            deleteText: 'Eliminar',
            deleting: 'Eliminando',
            error: 'Error',
            close: 'Cerrar',
            cannotLoadOptionsFor: 'No se pueden cargar las opciones para el campo {0}',
            pagingInfo: 'Mostrando registros {0} a {1} de {2}',
            canNotDeletedRecords: 'No se puede borrar registro(s) {0} de {1}!',
            deleteProggress: 'Eliminando {0} de {1} registros, procesando...',
            pageSizeChangeLabel: 'Registros por página',
            gotoPageLabel: 'Ir a página'
        }
    });
}
function cambiopob()
{

    f = $('#buscar').val();
    $('#empresas').jtable('load',
            {
                buscar: f
            }
    );
}

function i_puesto(origen, destino)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/i_puesto', //the method in controller
        data: 'origen=' + origen + '&destino=' + destino,
        success: function (resp)
        {
            $.ajax({
                type: 'POST',
                url: '/pofecam/index.php/eval_ajax/cambio_fecha_centro_ajax_puesto', //the method in controller
                data: 'id_area=' + destino
            });
            location.reload();
        }
    });
}
function m_puesto(origen, destino)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/m_puesto', //the method in controller
        data: 'origen=' + origen + '&destino=' + destino,
        success: function (resp)
        {
            $.ajax({
                type: 'POST',
                url: '/pofecam/index.php/eval_ajax/cambio_fecha_centro_ajax_mpuesto', //the method in controller
                data: 'id_puesto=' + destino
            });
            location.reload();
        }
    });
}
function i_area(origen, destino)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/i_area', //the method in controller
        data: 'origen=' + origen + '&destino=' + destino,
        success: function (resp)
        {
            $.ajax({
                type: 'POST',
                url: '/pofecam/index.php/eval_ajax/cambio_fecha_centro_ajax', //the method in controller
                data: 'id_centro=' + destino
            });
            location.reload();
        }
    });
}
function m_area(origen, destino)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/m_area', //the method in controller
        data: 'origen=' + origen + '&destino=' + destino,
        success: function (resp)
        {
            $.ajax({
                type: 'POST',
                url: '/pofecam/index.php/eval_ajax/cambio_fecha_centro_ajax_puesto', //the method in controller
                data: 'id_area=' + destino
            });
            location.reload();
        }
    });
}
function i_centro(origen, destino)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/i_centro', //the method in controller
        data: 'origen=' + origen + '&destino=' + destino,
        success: function (resp)
        {
            location.reload();
        }
    });
}
function cdelete(tipo, id, status)
{
    if ($('#' + tipo + id).prop('checked'))
        status = 'true';
    else
        status = 'false';
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/delete', //the method in controller
        data: 'tipo=' + tipo + '&id=' + id + '&status=' + status
    });
}
function purgar(id_empresa)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/importar_ajax/purgar', //the method in controller
        data: 'id_empresa=' + id_empresa,
        success: function ()
        {
            location.reload();
        }
    });
}