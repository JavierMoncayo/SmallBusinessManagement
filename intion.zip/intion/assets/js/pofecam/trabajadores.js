$(function () // on document load
{

    $(".puesto").droppable({
        accept: ".trabajador",
        activeClass: "ui-state-hover",
        hoverClass: "ui-state-active",
        drop: function (event, ui) {
            if (ui.draggable.attr('id') == 'tna')
            {
                id_puesto = $(this).attr('id_puesto');
                $('.trabajador_na').each(function (index) {
                    asignar_puesto($(this).attr('id_trabajador'), $(this).attr('old_puesto'), id_puesto, false);
                });
                location.reload();
            } else
                asignar_puesto(ui.draggable.attr('id_trabajador'), ui.draggable.attr('old_puesto'), $(this).attr('id_puesto'), true)
        }
    });

    $(".trabajadores_no_asignados").droppable({
        accept: ".trabajador",
        drop: function (event, ui) {

            desasignar_puesto(ui.draggable.attr('id_trabajador'), ui.draggable.attr('old_puesto'))
        }
    });

    $(".paro").droppable({
        accept: ".trabajador",
        drop: function (event, ui) {
            if (ui.draggable.attr('id') == 'tna')
            {
                id_puesto = $(this).attr('id_puesto');
                $('.trabajador_na').each(function (index) {
                    despedir($(this).attr('id_trabajador'), $(this).attr('old_puesto'), false);
                });
                location.reload();
            } else
                despedir(ui.draggable.attr('id_trabajador'), ui.draggable.attr('old_puesto'), true)
        }
    });
    $(".trabajador").draggable();
    //$('trabajador_na').draggable();
}
);
function asignar_puesto(id_trabajador, old_puesto, id_puesto, reload)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/trabajadores_c/asignar_puesto', //the method in controller
        data: 'id_trabajador=' + id_trabajador + '&id_puesto=' + id_puesto + '&old_puesto=' + old_puesto,
        success: function (resp)
        {
            if (reload)
                location.reload();
        }
    });
}
function desasignar_puesto(id_trabajador, old_puesto)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/trabajadores_c/desasignar_puesto', //the method in controller
        data: 'id_trabajador=' + id_trabajador + '&old_puesto=' + old_puesto,
        success: function (resp)
        {
            location.reload();
        }
    });
}
function despedir(id_trabajador, old_puesto, reload)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/trabajadores_c/despedir', //the method in controller
        data: 'id_trabajador=' + id_trabajador + '&old_puesto=' + old_puesto,
        success: function (resp)
        {
            if (reload)
                location.reload();
        }
    });
}
function testdni()
{
    var lockup = 'TRWAGMYFPDXBNJZSQVHLCKE';
    dni = $('#dni').val();
    $('#letra').html('<b>' + lockup.charAt(dni % 23) + '</b>');
}
function salvar(campo)
{
    var id_trabajador;    // if 0, the row is not created yet
    var valor = $('#' + campo).val();
    id_trabajador = $('#id_trabajador').val()
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/actualizar_campo', //the method in controller
        data: 'id_trabajador=' + id_trabajador + '&campo=' + campo + '&valor=' + valor,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            actualizar(resp);
        }
    })
}
function buscardni()
{
    if ($('#dni').val() == '')
    {
        $('#dni').focus();
        return;
    }
    valor = $('#dni').val() + $('#letra').text();           // letter appended
    id_trabajador = $('#id_trabajador').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/trabajadores_c/buscardni', //the method in controller
        data: 'dni=' + valor,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            if (resp.error != '')
                alert(resp.error)
            $('#id_trabajador').val(resp.id);          // set the ajax response as new id for editing
            if (!$('#trab_' + resp.id).length)    // the worker does not exist so we ned to add
                $('#no_asignados').prepend("<tr style='background:#F3F781'><td class='trabajador' style='background:#F3F781' id_trabajador='" + resp.id + "' old_puesto='0' id='trab_" + resp.id + "'>" + resp.nombre + "</td></tr>");
            actualizar(resp);
            $('#nombre').focus();
        }
    })

}
function editar(id_trabajador)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/obtener_trabajador', //the method in controller
        data: 'id_trabajador=' + id_trabajador,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            $('#id_trabajador').val(resp.id);          // set the ajax response as new id for editing
            $('#dni').val(resp.dni);
            actualizar(resp);
            $('#nombre').focus();

        }
    })
}
function actualizar(trabajador)
{
    if (trabajador.nombre != '[Pendiente de introducir nombre]')
        $('#nombre').val(trabajador.nombre); // Update only if name was provided
    $('#nombre').prop('disabled', false);
    $('#id_genero').val(trabajador.id_genero);
    $('#id_genero').prop('disabled', false);
    $('#numero_ss').val(trabajador.numero_ss);
    $('#numero_ss').prop('disabled', false);
    $('#f_nac').val(trabajador.f_nac);
    $('#f_nac').prop('disabled', false);
    $('#minusvalia').val(trabajador.minusvalia);
    $('#minusvalia').prop('disabled', false);
    $('#id_area_funcional').val(trabajador.id_area_funcional);
    $('#id_area_funcional').prop('disabled', false);
    $('#id_grupo_cotizacion').val(trabajador.id_grupo_cotizacion);
    $('#id_grupo_cotizacion').prop('disabled', false);
    $('#id_estudios').val(trabajador.id_estudios);
    $('#id_estudios').prop('disabled', false);
    $('#trab_' + trabajador.id).html(trabajador.dni + ' ' + trabajador.nombre);
}
function limpia()
{
    $('#nombre').val('');
    $('#nombre').prop('disabled', true);
    $('#id_genero').val(1);
    $('#id_genero').prop('disabled', true);
    $('#numero_ss').val('');
    $('#numero_ss').prop('disabled', true);
    $('#f_nac').val('');
    $('#f_nac').prop('disabled', true);
    $('#minusvalia').val('');
    $('#minusvalia').prop('disabled', true);
    $('#id_area_funcional').val(0);
    $('#id_area_funcional').prop('disabled', true);
    $('#id_grupo_cotizacion').val(0);
    $('#id_grupo_cotizacion').prop('disabled', true);
    $('#id_estudios').val(0);
    $('#id_estudios').prop('disabled', true);
    $('#dni').val('');
    $('#dni').focus();
    $('#id_trabajador').val('');
}