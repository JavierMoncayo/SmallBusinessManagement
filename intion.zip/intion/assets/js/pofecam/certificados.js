/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(function ()
{
    $('input.datepicker').datepicker();
})

function toggle_checkboxes(clase)
{
    $('.' + clase).prop('checked', $('#mastercheck-' + clase).prop('checked'));
    actualizar_textarea();
}
function actualizar_textarea()
{
    var lista_currantes = '';
    var conta = 0;
    $('.chkbx').each(function ()
    {
        if ($(this).prop('checked'))
        {
            lista_currantes = lista_currantes + '\n' + $(this).val();
            conta++;
        }
    }
    );
    if (conta > 1)
        s_p = 'a los trabajadores:';
    else
        s_p = 'al trabajador:';
    texto = 'Se imparte formación e información en el puesto de trabajo según los artículos 18 y 19 de la Ley de Prevención de Riesgos Laborales 31/1995 ' + s_p + lista_currantes +
            '\nSe entrega documentación para la empresa.';
    if (conta != 0)
        $('#aspectos').html(texto);
}
function actualizar_textarea_agricultura()
{
    var lista_currantes = '';
    var conta = 0;
    $('.chkbx').each(function ()
    {
        if ($(this).prop('checked'))
        {
            lista_currantes = lista_currantes + '\n' + $(this).val();
            conta++;
        }
    }
    );
    if (conta == 0)
        conta = ' ';
    texto = 'Se imparte formación e información en el puesto de trabajo según los artículos 18 y 19 de la Ley de Prevención de Riesgos Laborales 31/1995 a los trabajadores:'
            + lista_currantes +
            '\nSe entrega documentación para la empresa.\n\
Se recuerda a la empresa que ante cambios, nuevas contrataciones o si ocurren accidentes de trabajo deberá avisar a Prevecam \n';

    $('#aspectos').html(texto);
}
function area_cambiar()
{

}