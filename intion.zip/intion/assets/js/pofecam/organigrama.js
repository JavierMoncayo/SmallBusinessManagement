//Funciones para Jquery-ui (acordeon, datepicker, etc...)
$(function () {
    $("div.accordion")
            .accordion
            ({
                heightStyle: "content",
                collapsible: true,
                autoHeight: true,
                active: false
            });
    $(document).tooltip();
    $(".datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        yearRange: "c-70:c"
    });

    $("#divevalform").hide();
});
function enfocar(elemento)
{
    var focalizar = $("#" + elemento).position().top;
    $('html,body').animate({scrollTop: focalizar}, 1000);
}
function form_eval_area(id_eval)
{
    if (id_eval != 0)
        $('#tra' + id_eval).css("background", "yellow");
    dialog = $("#divevalform").dialog(
            {
                autoOpen: false,
                height: 700,
                width: '80%',
                modal: true,
                buttons:
                        {
                            Cerrar: function ()
                            {
                                dialog.dialog("close");
                                $('#tra' + id_eval).css("background", "white");
                            }
                        },
                close: function ()
                {
                    //allFields.removeClass( "ui-state-error" );
                    dialog.dialog("close");
                    $('#tra' + id_eval).css("background", "white");
                }
            });
    dialog.dialog("open");
}
function ajustar_fr(id_eval, tipo)
{
    code = $('#fr').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/get_fr_desc', //the method in controller
        data: 'codigo=' + code + '&id_eval=' + id_eval,
        success: function (resp)
        {
            $('#fr_code').html(code);
            $('#deficiencia').val(resp);
            gr_eval(tipo, id_eval, 'deficiencia');
            gr_eval(tipo, id_eval, 'fr');
        }
    })
}
function ajustar_cr(id_eval, tipo)
{
    code = $('#cr').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/get_cr_desc', //the method in controller
        data: 'codigo=' + code + '&id_eval=' + id_eval,
        success: function (resp)
        {
            $('#cr_code').html(code);
            $('#riesgo').val(resp);
            gr_eval(tipo, id_eval, 'riesgo');
            gr_eval(tipo, id_eval, 'cr');
        }
    })
}
function nueva_eval_area(id_area)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/editar_eval_area', //the method in controller
        data: 'eval=0&area=' + id_area,
        success: function (resp)
        {
            $('#divevalform').html(resp);
            //$('#a' + area).show();
            form_eval_area(0);
            $(".datepicker").datepicker();
            $('#a' + id_area).hide();
            get_eval(id_area);
        }

    })
}
function nueva_eval_puesto(id_puesto)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/editar_eval_puesto', //the method in controller
        data: 'eval=0&puesto=' + id_puesto,
        success: function (resp)
        {
            $('#divevalform').html(resp);
            //$('#a' + area).show();
            form_eval_puesto(0);
            $(".datepicker").datepicker();
            $('#p' + id_puesto).hide();
            get_eval_puesto(id_puesto);
        }

    })
}
function editar_eval_area(id_eval)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/editar_eval_area', //the method in controller
        data: 'eval=' + id_eval,
        success: function (resp)
        {
            $('#divevalform').html(resp);
            //$('#a' + area).show();
            form_eval_area(id_eval);
            $(".datepicker").datepicker();
        }
    })
}
function form_eval_puesto(id_eval)
{
    if (id_eval != 0)
        $('#trp' + id_eval).css("background", "yellow");
    dialog = $("#divevalform").dialog(
            {
                autoOpen: false,
                height: 600,
                width: '80%',
                modal: true,
                buttons:
                        {
                            Cerrar: function ()
                            {
                                dialog.dialog("close");
                                $('#trp' + id_eval).css("background", "white");
                            }
                        },
                close: function ()
                {
                    //allFields.removeClass( "ui-state-error" );
                    dialog.dialog("close");
                    $('#trp' + id_eval).css("background", "white");
                }
            });
    dialog.dialog("open");
}
function editar_eval_puesto(id_eval)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/editar_eval_puesto', //the method in controller
        data: 'eval=' + id_eval,
        success: function (resp)
        {
            $('#divevalform').html(resp);
            //$('#a' + area).show();
            form_eval_puesto(id_eval);
        }
    })
}
function borrar_eval_puesto(id_linea, id_puesto)
{
    $('#trp' + id_linea).css("background", "yellow");
    d = $("#dialog");
    dialogo = $("#dialog").dialog({
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 300
        },
        hide: {
            effect: "explode",
            duration: 300
        },
        buttons: {
            "Aceptar": function ()
            {
                $.ajax({
                    type: 'POST',
                    url: '/pofecam/index.php/eval_ajax/borrar_eval_puesto', //the method in controller
                    data: 'id_eval_puesto=' + id_linea + '&id_puesto=' + id_puesto,
                    success: function (resp)
                    {
                        $('#p' + id_puesto).html(resp);
                    }
                });
                $(this).dialog("close");
                $('#trp' + id_linea).css("background", "white");

            },
            "Cancelar": function ()
            {
                $('#trp' + id_linea).css("background", "white");
                $(this).dialog("close");
            }
        }
    });
    dialogo.dialog("open");
}
function borrar_eval_area(id_linea, id_area)
{
    $('#tra' + id_linea).css("background", "yellow");
    d = $("#dialog");
    dialogo = $("#dialog").dialog({
        autoOpen: false,
        close: function (event, ui) {
            $('#tra' + id_linea).css("background", "white");
        },
        show: {
            effect: "blind",
            duration: 300
        },
        hide: {
            effect: "explode",
            duration: 300
        },
        buttons: {
            "Aceptar": function ()
            {
                $.ajax({
                    type: 'POST',
                    url: '/pofecam/index.php/eval_ajax/borrar_eval_area', //the method in controller
                    data: 'id_eval_area=' + id_linea + '&id_area=' + id_area,
                    success: function (resp)
                    {
                        $('#a' + id_area).html(resp);
                    }
                });
                $(this).dialog("close");
                $('#tra' + id_linea).css("background", "white");
            },
            "Cancelar": function ()
            {
                $('#tra' + id_linea).css("background", "white");
                $(this).dialog("close");
            }
        }
    });
    dialogo.dialog("open");
}
function get_eval(area, sort, toggle)
{
    toggle = typeof toggle !== 'undefined' ? toggle : true;
    if (toggle && $('#a' + area).is(':visible'))
    {
        $('#a' + area).hide();
        return
    }
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/get_eval_area', //the method in controller
        data: 'area=' + area + '&sort=' + sort,
        success: function (resp)
        {
            $('#dialog').hide();
            $('#a' + area).html(resp);
            $('#a' + area).show();
        }
    })
}
function get_eval_puesto(puesto, sort, toggle)
{
    toggle = typeof toggle !== 'undefined' ? toggle : true;
    if ($(toggle && '#p' + puesto).is(':visible'))
    {
        $('#p' + puesto).hide();
        return
    }
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/get_eval_puesto', //the method in controller
        data: 'puesto=' + puesto + '&sort=' + sort,
        success: function (resp)
        {
            $('#dialog').hide();
            $('#p' + puesto).html(resp);
            $('#p' + puesto).show();
        }
    })
}
// when new center is clicked, the hidden div has to be shown
function gr_eval(tipo, id, campo)
{
    if (tipo == 'a')
        fila = 'tra' + id;
    else
        fila = 'trp' + id;
    valor = $('#' + campo).val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/gr_eval', //the method in controller
        data: 'tipo=' + tipo + '&id=' + id + '&campo=' + campo + '&valor=' + valor,
        success: function (resp)
        {
            $('#' + fila).html(resp);
        }
    })
}
function gr_calc_eval(tipo, id)
{
    nd = $('#nd').val();
    ne = $('#ne').val();
    cr2 = $('#cr2').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/eval_ajax/gr_calc_eval', //the method in controller
        data: 'tipo=' + tipo + '&id=' + id + '&nd=' + nd + '&ne=' + ne + '&cr2=' + cr2,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            $('#calc_ni').html(resp.html);
            if (tipo == 'a')
            {
                if (resp.dias > 0)
                    f_fin = sumaFecha(resp.dias, $('#f_ini').val());
                if (resp.dias == -1)
                    f_fin = 'Contínuo';
                if (resp.dias == -2)
                    f_fin = '';
            } else    // in puestos eval, f_fin always is 'Permanente'
            {
                f_fin = 'Permanente';
            }
            $('#f_fin').val(f_fin);
            gr_eval(tipo, id, 'f_fin')

        }
    })
}
sumaFecha = function (d, fecha)
{
    var Fecha = new Date();
    var sFecha = fecha || (Fecha.getDate() + "/" + (Fecha.getMonth() + 1) + "/" + Fecha.getFullYear());
    var sep = sFecha.indexOf('/') != -1 ? '/' : '-';
    var aFecha = sFecha.split(sep);
    var fecha = aFecha[2] + '/' + aFecha[1] + '/' + aFecha[0];
    fecha = new Date(fecha);
    fecha.setDate(fecha.getDate() + parseInt(d));
    var anno = fecha.getFullYear();
    var mes = fecha.getMonth() + 1;
    var dia = fecha.getDate();
    mes = (mes < 10) ? ("0" + mes) : mes;
    dia = (dia < 10) ? ("0" + dia) : dia;
    var fechaFinal = dia + sep + mes + sep + anno;
    return (fechaFinal);
}
function nuevo_centro()
{
    //$('#nuevo_centro').css("display", "block"); // just display the div
    diveditarcentro = $('#nuevo_centro').dialog(
            {
                autoOpen: false,
                height: 600,
                width: '80%',
                modal: true,
                buttons:
                        {
                            Copiar_de_empresa: function ()
                            {
                                copiar_datos_empresa();
                            },
                            Cerrar: function ()
                            {
                                diveditarcentro.dialog("close");
                            }
                        },
                close: function ()
                {
                    //allFields.removeClass( "ui-state-error" );
                    diveditarcentro.dialog("close");
                    location.reload();
                }
            });
    diveditarcentro.dialog("open");
    $('#nombre').focus();                       // and start editing. Nothing more to do until name is not filled
}
// when new area image is clicked, the hidden div has to be shown
function nueva_area(id_centro)
{
    //$('#nueva_area').css("display", "block"); // just display the div
    diveditararea = $('#nueva_area').dialog(
            {
                autoOpen: false,
                height: 600,
                width: '80%',
                modal: true,
                buttons:
                        {
                            Cerrar: function ()
                            {
                                diveditararea.dialog("close");
                                $('#id_nueva_area').val('0');      // resets current area id
                            }
                        },
                close: function ()
                {
                    diveditararea.dialog("close");
                    $('#id_nueva_area').val('0');      // resets current area id
                }
            });
    diveditararea.dialog("open");
    $('#area_nombre').focus();                // and start editing. Nothing more to do until name is not filled
    $('#id_centro').val(id_centro);      // set centro id

}
// changes via ajax a row of centros table.
function cambiar(campo)
{
    //if is the very first time it comes here, it has to insert a new row, put the id in the hidden var and enable all edit fields
    id_centro = $('#id_nuevo_centro').val();
    id_empresa = $('#id_empresa').val();
    dato = $('#' + campo).val();
    if (id_centro == '0')
        alta_centro(id_empresa, dato);
    else
        actualizar_campo_centro(id_centro, campo, dato);

}
function area_cambiar(campo)
{
    //if is the very first time it comes here, it has to insert a new row, put the id in the hidden var and enable all edit fields
    id_centro = $('#id_centro').val();      // recovers centro id
    id_area = $('#id_nueva_area').val();    // new area flag (0 means new one)
    dato = $('#area_' + campo).val();
    if (id_area == '0')
        alta_area(id_centro, dato);
    else
        actualizar_campo_area(id_area, campo, dato);

}
//Private. Updates a single value
function actualizar_campo_centro(id_centro, campo, valor)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/actualizar_campo_centro', //the method in controller
        data: 'id_centro=' + id_centro + '&campo=' + campo + '&valor=' + valor,
    });
    if (campo == 'nombre')
        $('#acc' + id_centro).html(valor);
}
function actualizar_campo_area(id_area, campo, valor)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/actualizar_campo_area', //the method in controller
        data: 'id_area=' + id_area + '&campo=' + campo + '&valor=' + valor,
    });
}
// Inserts a new row in centros table and return the new ID
function alta_centro(id_empresa, nombre)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/alta_centro', //the method in controller
        data: 'id_empresa=' + id_empresa + '&nombre=' + nombre,
        success: function (resp)
        { // after processed, hidden field id_nuevo_centro takes new value
            $('#id_nuevo_centro').val(resp);
//            $('#div_centros').append('<h3>' + nombre + '</h3><div>\n\
//            <img height="60" width="80" src="/pofecam/imagenes/organigrama_editar.png" onclick="editarcentro(' + resp + ')" title="Modificar los datos del centro' + nombre + '">\n\
//            <img height="60" width="80" src="/pofecam/imagenes/organigrama_borrar.png" onclick="borrarcentro(' + resp + ')" title="Eliminar ' + nombre + '">\n\
//            <b><I>Generar:    </I></b><button disabled >Planif. Áreas</button><button disabled >Evaluacion Áreas</button>\n\
//            <h1>Areas<img height="60" width="80" src="/pofecam/imagenes/organigrama_nuevo.jpg" title="Crear nueva área asociada al centro ' + nombre + '"></h1>            ');
//            $('#div_centros').accordion("refresh");
//            $('#acc0').click();
            centros_enable();
            $('#f_eval').focus();
        }
    });
}
function alta_area(id_centro, nombre)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/alta_area', //the method in controller
        data: 'id_centro=' + id_centro + '&nombre=' + nombre,
        success: function (resp)
        { // after processed, hidden field id_nuevo_centro takes new value
            resp = JSON.parse(resp);
            $('#id_nueva_area').val(resp.id);      // updates current area id
            //areas_enable();
            $('#area_localizacion').focus();
            $('#div_areas_' + id_centro).append(resp.html);
            $('#div_areas_' + id_centro).accordion("refresh");
            $('#div_puestos_' + resp.id).accordion({
                heightStyle: "content",
                collapsible: true,
                autoHeight: true,
                active: false
            });
            $('#borrarcentro_' + id_centro).hide();
        }
    });
}
// Erases the given centro row and reloads page
function borrarcentro(id_centro)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/baja_centro', //the method in controller
        data: 'id_centro=' + id_centro,
        success: function (resp)
        {
            location.reload();
        }
    });
}
function borrararea(id_area)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/baja_area', //the method in controller
        data: 'id_area=' + id_area,
        success: function (resp)
        {
            location.reload();
        }
    });
}
function borrarpuesto(id_puesto)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/baja_puesto', //the method in controller
        data: 'id_puesto=' + id_puesto,
        success: function (resp)
        {
            location.reload();
        }
    });
}
// Set up a centro to be edited
// TODO: If name changes, accordeon should changes too
function editarcentro(id_centro)
{
    resp = new Array();
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/obtener_centro', //the method in controller
        data: 'id_centro=' + id_centro, // centro ID as identifier
        success: function (json_resp)               // and JSON encoded response
        {                                           // after processed, hidden field id_nuevo_centro takes new value
            resp = JSON.parse(json_resp);           // resp is now available for Javascript
            $('#id_nuevo_centro').val(id_centro);   // updates the currently editing value
            centros_set(resp);                      // assigns the obtained values to form fields
            centros_enable();                       // set property enabled
            nuevo_centro();                       // make div visible

        }
    });
}
function editararea(id_area)
{
    resp = new Array();
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/obtener_area', //the method in controller
        data: 'id_area=' + id_area, // area ID as identifier
        success: function (json_resp)               // and JSON encoded response
        {                                           // after processed, hidden field id_nueva_area takes new value
            resp = JSON.parse(json_resp);           // resp is now available for Javascript
            $('#id_nueva_area').val(id_area);       // updates the currently editing value
            $('#id_centro').val(resp.id_centro);    // updates the current centro
            areas_set(resp);                        // assigns the obtained values to form fields
            //areas_enable();                         // set property enabled
            nueva_area(resp.id_centro);                           // make div visible

        }
    });
}
function editarpuesto(id_puesto)
{
    resp = new Array();
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/obtener_puesto', //the method in controller
        data: 'id_puesto=' + id_puesto, // id_puesto ID as identifier
        success: function (json_resp)              // and JSON encoded response
        {                                           // after processed, hidden field id_nueva_area takes new value
            resp = JSON.parse(json_resp);           // resp is now available for Javascript
            $('#id_nuevo_puesto').val(id_puesto);   // updates the currently editing value
            $('#id_centro').val(resp.id_centro);    // updates the current centro
            $('#id_area').val(resp.id_area);        // and the current area
            puestos_set(resp);                      // assigns the obtained values to form fields
            nuevo_puesto(resp.id_centro, resp.id_area);           // make div visible

        }
    });
}
function actualizar_es_maquina()
{
    var esmaquina = $('#esmaquina').prop('checked');        // esmaquina: true/false
    var id_puesto = $('#id_nuevo_puesto').val();            // id_puesto(even if it's new)
    var puesto_nombre = $('#puesto_nombre').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/actualizar_maquina', //the method in controller
        data: 'id_puesto=' + id_puesto + '&esmaquina=' + esmaquina + '&puesto_nombre=' + puesto_nombre, // area ID as identifier
    });

}
function nuevo_puesto(id_area)
{
    //$('#nuevo_puesto').css("display", "block");   // just display the div
    diveditpuesto = $('#nuevo_puesto').dialog(
            {
                autoOpen: false,
                height: 600,
                width: '80%',
                modal: true,
                buttons:
                        {
                            Cerrar: function ()
                            {
                                diveditpuesto.dialog("close");
                                $('#id_nuevo_puesto').val('0');      // resets current workplace id
                                puestos_reset();
                            }
                        },
                close: function ()
                {
                    diveditpuesto.dialog("close");
                    $('#id_nuevo_puesto').val('0');      // resets current workplace id
                    puestos_reset();
                }
            });
    diveditpuesto.dialog("open");
    $('#puesto_nombre').focus();                  // and start editing. Nothing more to do until name is not filled
    $('#id_area').val(id_area);                 // set area id

}
function alta_puesto(id_area, nombre)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/alta_puesto', //the method in controller
        data: 'id_area=' + id_area + '&nombre=' + nombre,
        success: function (resp)
        { // after processed, hidden field id_nuevo_centro takes new value
            resp = JSON.parse(resp);
            $('#id_nuevo_puesto').val(resp.id);      // updates current area id
            $('#puesto_descripcion').focus();
            $('#div_puestos_' + id_area).append(resp.html);
            $('#div_puestos_' + id_area).accordion("refresh");
            $('#borrararea_' + id_area).hide();
        }
    });
}
function puesto_cambiar(campo)
{
    //if is the very first time it comes here, it has to insert a new row, put the id in the hidden var and enable all edit fields
    id_area = $('#id_area').val();    // new area flag (0 means new one)
    id_puesto = $('#id_nuevo_puesto').val();    // new area flag (0 means new one)
    dato = $('#puesto_' + campo).val();
    if (id_puesto == '0')
        alta_puesto(id_area, dato);
    else
        actualizar_campo_puesto(id_puesto, campo, dato);
}
function actualizar_campo_puesto(id_puesto, campo, valor)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/actualizar_campo_puesto', //the method in controller
        data: 'id_puesto=' + id_puesto + '&campo=' + campo + '&valor=' + valor,
    });
}

// Reads empresa data via ajax, and set all values for editing
function copiar_datos_empresa()
{
    id_centro = $('#id_nuevo_centro').val();    // get the center id
    id_empresa = $('#id_empresa').val();    // get the comp id
    $.ajax({
        type: 'POST',
        url: '/pofecam/eval_ajax/copiar_datos_empresa', //the method in controller
        data: 'id_centro=' + id_centro + '&id_empresa=' + id_empresa,
        success: function (json_resp)
        { // after processed, hidden field id_nuevo_centro takes new value
            resp = JSON.parse(json_resp);
            centros_set(resp);  // set editing values  
            //centros_disable();  // disable editing
            $('#id_nuevo_centro').val(resp.id_centro);      // updates current id value
            // and add the new accordion element to actual
//            $('#div_centros').append('<h3>' + resp.nombre + '</h3><div>\n\
//            <img height="60" width="80" src="/pofecam/imagenes/organigrama_editar.png" onclick="editarcentro(' + resp.id_centro + ')" title="Modificar los datos del centro' + resp.nombre + '">\n\
//            <img height="60" width="80" src="/pofecam/imagenes/organigrama_borrar.png" onclick="borrarcentro(' + resp.id_centro + ')" title="Eliminar ' + resp.nombre + '">\n\
//            <b><I>Generar:    </I></b><button disabled >Planif. Áreas</button><button disabled >Evaluacion Áreas</button>\n\
//            <h1>Areas<img height="60" width="80" src="/pofecam/imagenes/organigrama_nuevo.jpg" title="Crear nueva área asociada al centro ' + resp.nombre + '"></h1>            ');
//            //$('#div_centros').accordion("refresh");         // refresh. 
            $('#acc' + id_centro).click();                             // This closes 
            $('#f_eval').focus();
        }
    });
}
// Put all fields disabled
function centros_disable()
{
    return;
    $('#direccion').prop('disabled', true);
    $('#poblacion').prop('disabled', true);
    $('#provincia').prop('disabled', true);
    $('#telefono').prop('disabled', true);
    $('#observaciones').prop('disabled', true);
    $('#f_eval').prop('disabled', true);
    $('#coordinador').prop('disabled', true);
    $('#responsable').prop('disabled', true);
    $('#cp').prop('disabled', true);

}
function areas_disable()
{
    return;
    $('#area_localizacion').prop('disabled', true);
    $('#area_id_evaluador').prop('disabled', true);
    $('#area_observaciones').prop('disabled', true);
    $('#area_normas').prop('disabled', true);
    $('#area_usoepi').prop('disabled', true);
}
// Put all fields enabled
function centros_enable()
{
    $('#direccion').prop('disabled', false);
    $('#poblacion').prop('disabled', false);
    $('#provincia').prop('disabled', false);
    $('#telefono').prop('disabled', false);
    $('#observaciones').prop('disabled', false);
    $('#f_eval').prop('disabled', false);
    $('#coordinador').prop('disabled', false);
    $('#responsable').prop('disabled', false);
    $('#cp').prop('disabled', false);
}

// Put the given values (object) in each field
function centros_set(resp)
{
    $('#nombre').val(resp.nombre);
    $('#titulo').html(resp.nombre);
    $('#direccion').val(resp.direccion);
    $('#poblacion').val(resp.poblacion);
    $('#provincia').val(resp.provincia);
    $('#telefono').val(resp.telefono);
    $('#observaciones').val(resp.observaciones);
    $('#f_eval').val(resp.f_eval);
    $('#coordinador').val(resp.coordinador);
    $('#responsable').val(resp.responsable);
    $('#cp').val(resp.cp);
    $('#orden').val(resp.orden);
    $("select#tipo_eval").val(resp.tipo_eval);

}
function areas_set(resp)
{
    $('#area_nombre').val(resp.nombre);
    $('#area_titulo').html(resp.nombre);
    $('#area_localizacion').val(resp.localizacion);
    $('#area_id_evaluador').val(resp.id_evaluador);
    $('#area_observaciones').val(resp.observaciones);
    $('#area_normas').val(resp.normas);
    $('#area_usoepi').val(resp.usoepi);
    $('#area_orden').val(resp.orden);
}
function puestos_set(resp)
{
    $('#puesto_nombre').val(resp.nombre);
    $('#puesto_descripcion').val(resp.descripcion);
    $('#puesto_observaciones').val(resp.observaciones);
    $('#puesto_uso_epi').val(resp.uso_epi);
    $('#puesto_orden').val(resp.orden);
    $("#puesto_titulo").html(resp.nombre);
}
function puestos_reset()
{
    $('#puesto_nombre').val('');
    $('#puesto_descripcion').val('');
    $('#puesto_observaciones').val('');
    $('#puesto_uso_epi').val('');
}
// Put all fields value to 0
function centros_reset()
{
    $('#id_nuevo_centro').val('0');
    $('#nombre').val('');
    $('#titulo').html('');
    $('#direccion').val('');
    $('#poblacion').val('');
    $('#provincia').val('');
    $('#telefono').val('');
    $('#observaciones').val('');
    $('#f_eval').val('');
    $('#coordinador').val('');
    $('#responsable').val('');
    $('#cp').val('');
}
function areas_reset()
{
    $('#area_nombre').val('');
    $('#area_localizacion').val('');
    $('#area_id_evaluador').val('');
    $('#area_observaciones').val('');
    $('#area_normas').val('Normas y procedimientos: Manual de Prevención de Riesgos Laborales (Ley de PRL, Primeros Auxilios, Medidas de emergencia...) y Manual de Riesgos Específicos el puesto de trabajo.');
    $('#area_usoepi').val();
    $('#id_nueva_area').val('0');

}
function generar_manual(id_centro)
{

    $('.gen_man').prop('disabled', true);
    $('#w' + id_centro).show();
    $('#bt_download' + id_centro).prop('disabled', true);
    $.ajax({
        type: 'POST',
        url: '/pofecam/mk_manual/index/' + id_centro, //the method in controller
        success: function (resp)
        {
            // after processed, hidden field id_nuevo_centro takes new value
            $('#bt_download' + id_centro).prop('disabled', false);
            $('#w' + id_centro).hide();
            if (resp != '')
            {
                resp = JSON.parse(resp);
                if (resp.codigo > 0)
                    alert(resp.error);
            }
        }
    });
}

function download(id_centro)
{
    window.location.href = "mk_manual/download/" + id_centro;
}
function generar_memoria(id_centro)
{

    $('.gen_mem').prop('disabled', true);


    $('#w' + id_centro).show();
    $('#bt_download_memo' + id_centro).prop('disabled', true);
    $.ajax({
        type: 'POST',
        url: '/pofecam/mk_memoria/index/' + id_centro, //the method in controller
        //data: 'id_empresa=' + id_empresa + '&nombre=' + nombre,
        success: function ()
        { // after processed, hidden field id_nuevo_centro takes new value
            $('#bt_download_memo' + id_centro).prop('disabled', false);
            $('#w' + id_centro).hide();
        }
    });
}
function download_memoria(id_centro)
{
    window.location.href = "mk_memoria/download/" + id_centro;
}
function get_spanish()
{
    return {
        serverCommunicationError: 'Ocurrió un error en la comunicación con el servidor.',
        loadingMessage: 'Cargando registros...',
        noDataAvailable: 'No hay datos disponibles!',
        addNewRecord: 'Crear nuevo registro',
        editRecord: 'Editar registro',
        areYouSure: '¿Está seguro?',
        deleteConfirmation: 'El registro será eliminado. ¿Está seguro?',
        save: 'Guardar',
        saving: 'Guardando',
        cancel: 'Cancelar',
        deleteText: 'Eliminar',
        deleting: 'Eliminando',
        error: 'Error',
        close: 'Cerrar',
        cannotLoadOptionsFor: 'No se pueden cargar las opciones para el campo {0}',
        pagingInfo: 'Mostrando registros {0} a {1} de {2}',
        canNotDeletedRecords: 'No se puede borrar registro(s) {0} de {1}!',
        deleteProggress: 'Eliminando {0} de {1} registros, procesando...',
        pageSizeChangeLabel: 'Registros por página',
        gotoPageLabel: 'Ir a página'
    }
}
function setup_jtablesq(filtro) // returns the jtable code for the element properly labeled
{
    base = '/pofecam/index.php/organigrama/';
    etiqueta = 'Listado de productos químicos';
    $(document).ready(function () {
        $('#q' + filtro).jtable({
            title: etiqueta,
            paging: true, //Enable paging
            pageSize: 50, //Set page size
            pageSizes: [10, 25, 50, 100, 250, 500, 1000],
            pageList: 'minimal', // set the pagination buttons to tiny format
            sorting: true, //Enable sorting
            multiSorting: true, // Also, enable multisorting
            actions: {
                listAction: base + 'ldata?tabla=q&id_centro=' + filtro,
                updateAction: base + 'update?tabla=q',
                createAction: base + 'create?tabla=q' + '&id_centro=' + filtro,
                deleteAction: base + 'delete?tabla=q'
            },
            fields: {
                id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: false
                },
                nombre: {
                    title: 'Nombre',
                    list: true,
                    create: true,
                    edit: true
                },
                referencia: {
                    title: 'Núm. CAS',
                    list: true,
                    create: true,
                    edit: true
                },
                tipo: {
                    title: 'Tipo',
                    list: true,
                    create: true,
                    edit: true
                },
                fichas: {
                    title: 'Fichas',
                    list: false,
                    create: true,
                    edit: true
                },
                descripcion: {
                    title: 'Descripcion',
                    list: false,
                    create: true,
                    edit: true
                }
            },
            // set up spanish localization
            messages: get_spanish(),
        });
        $('#q' + filtro).jtable('load');
    })
}
function setup_jtablesv(filtro) // returns the jtable code for the element properly labeled
{
    base = '/pofecam/index.php/organigrama/';
    etiqueta = 'Listado de vehículos';
    $(document).ready(function () {
        $('#v' + filtro).jtable({
            title: etiqueta,
            paging: true, //Enable paging
            pageSize: 50, //Set page size
            pageSizes: [10, 25, 50, 100, 250, 500, 1000],
            pageList: 'minimal', // set the pagination buttons to tiny format
            sorting: true, //Enable sorting
            multiSorting: true, // Also, enable multisorting
            actions: {
                listAction: base + 'ldata?tabla=v&id_centro=' + filtro,
                updateAction: base + 'update?tabla=v',
                createAction: base + 'create?tabla=v' + '&id_centro=' + filtro,
                deleteAction: base + 'delete?tabla=v'
            },
            fields: {
                id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: false
                },
                marca: {
                    title: 'Marca',
                    list: true,
                    create: true,
                    edit: true
                },
                tipo: {
                    title: 'tipo',
                    list: true,
                    create: true,
                    edit: true
                },
                matricula: {
                    title: 'matricula',
                    list: false,
                    create: true,
                    edit: true
                },
                descripcion: {
                    title: 'Descripcion',
                    list: false,
                    create: true,
                    edit: true
                }
            },
            // set up spanish localization
            messages: get_spanish(),
        });
        $('#v' + filtro).jtable('load');
    })
}
function setup_jtablesm(filtro) // returns the jtable code for the element properly labeled
{
    base = '/pofecam/index.php/organigrama/';
    etiqueta = 'Listado de máquinas';
    $(document).ready(function () {
        $('#m' + filtro).jtable({
            title: etiqueta,
            paging: true, //Enable paging
            pageSize: 50, //Set page size
            pageSizes: [10, 25, 50, 100, 250, 500, 1000],
            pageList: 'minimal', // set the pagination buttons to tiny format
            sorting: true, //Enable sorting
            multiSorting: true, // Also, enable multisorting
            actions: {
                listAction: base + 'ldata?tabla=m&id_centro=' + filtro,
                updateAction: base + 'update?tabla=m',
                createAction: base + 'create?tabla=m' + '&id_centro=' + filtro,
                deleteAction: base + 'delete?tabla=m'
            },
            fields: {
                id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: false
                },
                tipo: {
                    title: 'Nombre',
                    list: true,
                    create: true,
                    edit: true
                },
                referencia: {
                    title: 'Marca y modelo',
                    list: false,
                    create: true,
                    edit: true
                },
                num_serie: {
                    title: 'Número de serie',
                    list: false,
                    create: true,
                    edit: true
                },
                ce: {
                    title: 'Marcado CE',
                    list: false,
                    create: true,
                    edit: true
                },
                adec9: {
                    title: 'Adecuación real decreto 1215/97',
                    list: false,
                    create: true,
                    edit: true
                },
                descripcion: {
                    title: 'Descripcion',
                    list: false,
                    create: true,
                    edit: true
                },
                observaciones: {
                    title: 'Observaciones',
                    list: false,
                    create: true,
                    edit: true
                }
            },
            // set up spanish localization
            messages: get_spanish(),
            //Initialize validation logic when a form is created
        });
        $('#m' + filtro).jtable('load');
    })
}
function togdiv(id_filtro, tabla)
{
    id_div = tabla + id_filtro;
    mi_div = $('#' + id_div); // handler del elemento div
    disp = mi_div.css('display');	// obtenemos el estado del div
    if (mi_div.attr('refresh') != undefined)	// this means that the attr is set
        obtener_tabla(mi_div.attr('refresh'), id_empresa);	// this have to set again the given field
    if (disp == 'block')	// si se esta mostrando
        mi_div.fadeOut('slow', function () {
            mi_div.css('display', 'none');
        });
    else
    {
        mi_div.fadeIn('slow', function () {
            mi_div.css('display', 'block');
        });
        if (tabla == 'q')
            setup_jtablesq(id_filtro);
        if (tabla == 'v')
            setup_jtablesv(id_filtro);
        if (tabla == 'm')
            setup_jtablesm(id_filtro);
        if (tabla == 't')
            setup_jtablest(id_filtro);
        if (tabla == 'mh')
            setup_jtablesmh(id_filtro);

    }

}
function setup_jtablest(filtro) // returns the jtable code for the element properly labeled
{
    base = '/pofecam/index.php/organigrama/';
    etiqueta = 'Trabajadores';
    $(document).ready(function () {
        $('#t' + filtro).jtable({
            title: etiqueta,
            paging: true, //Enable paging
            pageSize: 50, //Set page size
            pageSizes: [10, 25, 50, 100, 250, 500, 1000],
            pageList: 'minimal', // set the pagination buttons to tiny format
            sorting: true, //Enable sorting
            multiSorting: true, // Also, enable multisorting
            actions: {
                listAction: base + 'ldatat?id_puesto=' + filtro,
                updateAction: base + 'updatet',
                createAction: base + 'createt?id_puesto=' + filtro,
                deleteAction: base + 'deletet?id_puesto=' + filtro
            },
            fields: {
                id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: false
                },
                nombre: {
                    title: 'nombre',
                    list: true,
                    create: true,
                    edit: true
                },
                f_nac: {
                    title: 'Fecha de nacimiento',
                    list: false,
                    create: true,
                    edit: true
                },
                numero_ss: {
                    title: 'Número de afiliación a seg. social',
                    list: false,
                    create: true,
                    edit: true
                },
                dni: {
                    title: 'DNI',
                    list: false,
                    create: true,
                    edit: true
                },
                email: {
                    title: 'email',
                    list: false,
                    create: true,
                    edit: true
                },
                id_area_funcional: {
                    title: 'Area funcional',
                    list: false,
                    create: true,
                    edit: true,
                    options: function ()
                    {
                        return 'organigrama/ltrabopt?tabla=p_areas_funcionales';
                    }
                },
                id_grupo_cotizacion: {
                    title: 'Grupo de cotización',
                    list: false,
                    create: true,
                    edit: true,
                    options: function ()
                    {
                        return 'organigrama/ltrabopt?tabla=p_grupos_cotizacion';
                    }
                },
                id_estudios: {
                    title: 'Estudios',
                    list: false,
                    create: true,
                    edit: true,
                    options: function ()
                    {
                        return 'organigrama/ltrabopt?tabla=p_estudios_nivel';
                    }
                },
                id_genero: {
                    title: 'Genero',
                    options: {'0': '', '1': 'Masculino', '2': 'Femenino'},
                    list: false,
                    create: true,
                    edit: true
                }
            },
            // set up spanish localization
            messages: get_spanish(),
            //Initialize validation logic when a form is created
        });
        $('#t' + filtro).jtable('load');
    })
}
function setup_jtablesmh(filtro) // returns the jtable code for the element properly labeled
{
    base = '/pofecam/index.php/organigrama/';
    etiqueta = 'Mediciones higiénicas';
    $(document).ready(function () {
        $('#mh' + filtro).jtable({
            title: etiqueta,
            paging: true, //Enable paging
            pageSize: 50, //Set page size
            pageSizes: [10, 25, 50, 100, 250, 500, 1000],
            pageList: 'minimal', // set the pagination buttons to tiny format
            sorting: true, //Enable sorting
            multiSorting: true, // Also, enable multisorting
            actions: {
                listAction: base + 'ldatam?id_puesto=' + filtro,
                updateAction: base + 'updatem',
                createAction: base + 'createm?id_puesto=' + filtro,
                deleteAction: base + 'deletem?'
            },
            fields: {
                id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: false
                },
                fecha: {
                    title: 'fecha',
                    list: true,
                    create: true,
                    edit: true
                },
                precision: {
                    title: 'Precisión',
                    list: false,
                    create: true,
                    edit: true
                },
                medidor: {
                    title: 'Medidor',
                    list: false,
                    create: true,
                    default: 'PCE- EM882',
                    edit: true
                },
                observaciones: {
                    title: 'obs',
                    list: false,
                    create: true,
                    edit: true
                },
                ilum: {
                    title: 'Iluminación',
                    list: false,
                    create: true,
                    edit: true
                },
                temp: {
                    title: 'Temperatura',
                    list: false,
                    create: true,
                    edit: true
                },
                humed: {
                    title: 'Humedad',
                    list: false,
                    create: true,
                    edit: true
                },
                ruido: {
                    title: 'Ruido',
                    list: false,
                    create: true,
                    edit: true
                }
            },
            // set up spanish localization
            messages: get_spanish(),
            //Initialize validation logic when a form is created
        });
        $('#mh' + filtro).jtable('load');
    })
}
function sel_epi_pt(id)
{
    var current_epi = $('#puesto_uso_epi').val();  // save textarea contents
    // alert( $('#'+id).html());
    current_epi = current_epi + '\n' + $('#' + id).html();    // then, add a cr to the textarea field
    $('#puesto_uso_epi').val(current_epi);
    $('#' + id).hide();

    var id_puesto = $("#id_nuevo_puesto").val();
    actualizar_campo_puesto(id_puesto, 'uso_epi', current_epi);
}
function sel_epi_ar(id)
{
    var current_epi = $('#area_usoepi').val();  // save textarea contents
    // alert( $('#'+id).html());
    current_epi = current_epi + '\n' + $('#' + id).html();    // then, add a cr to the textarea field
    $('#area_usoepi').val(current_epi);
    $('#' + id).hide();

    var id_area = $("#id_nueva_area").val();
    actualizar_campo_area(id_area, 'usoepi', current_epi);
}
function sel_eval_area(id_area)
{
    var chk;
    chk = $('#area' + id_area).prop('checked');   // retrieve the status 
    $('.e' + id_area).prop('checked', chk);
}
function borrar_eval_area_tanda(id_area)
{
    elementos = $('.e' + id_area);    // class selector
    elementos.each(
            function (indice, elemento)
            {
                if ($(elemento).prop('checked')) // the row is checked
                    $.ajax({
                        type: 'POST',
                        url: '/pofecam/index.php/eval_ajax/borrar_eval_area', //the method in controller
                        data: 'id_eval_area=' + $(elemento).attr('data-ideval') + '&id_area=' + id_area,
                        success: function (resp)
                        {
                            $('#a' + id_area).html(resp);
                        }
                    });
            }
    )
}
function sel_eval_puesto(id_puesto)
{
    //chk;
    chk = $('#puesto' + id_puesto).prop('checked');   // retrieve the status 
    $('.ep' + id_puesto).prop('checked', chk);
}
function borrar_eval_puesto_tanda(id_puesto)
{
    elementos = $('.ep' + id_puesto);    // class selector
    elementos.each(
            function (indice, elemento)
            {
                if ($(elemento).prop('checked')) // the row is checked
                    $.ajax({
                        type: 'POST',
                        url: '/pofecam/index.php/eval_ajax/borrar_eval_puesto', //the method in controller
                        data: 'id_eval_puesto=' + $(elemento).attr('data-idevalp') + '&id_puesto=' + id_puesto,
                        success: function (resp)
                        {
                            $('#p' + id_puesto).html(resp);
                        }
                    });
            }
    )
}
