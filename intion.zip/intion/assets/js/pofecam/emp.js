function abrir_carpeta(id_nodo)
{
    $('#form').hide();

    $.ajax({
        type: 'POST',
        url: '/pofecam/empresas_c/abrir_carpeta', //the method in controller
        data: 'id_nodo=' + id_nodo + '&empresa=' + true, // #nodo as argument
        success: function (resp) { // after processed, the body is replaced by the new one
            $('#ad_tbody').html(resp);
        }
    });
}
function up()
{
    $('#form').hide();
    actual = $('#nodo_actual').val();	// actual node is stored into input hidden element
    $.ajax({
        type: 'POST',
        url: '/pofecam/empresas_c/up', //the method in controller
        data: 'actual=' + actual + '&empresa=' + true, // #nodo as argument
        success: function (resp) { // after processed, the body is replaced by the new one
            $('#ad_tbody').html(resp);
        }
    });
}
function ver_fichero(id)
{
    window.location = '/pofecam/empresas_c/verfichero/' + id, '';
}
function show_change_login()
{
    $('#form').show();
    $('#login').focus();
}