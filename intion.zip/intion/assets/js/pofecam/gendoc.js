
$(function () {
    $("input[type=submit],  button").button();
    $("#dialog").dialog({
        autoOpen: false,
        show: {
            effect: "blind",
            duration: 300
        },
        hide: {
            effect: "explode",
            duration: 300
        },
        buttons: {
            "Aceptar": function ()
            {
                $(this).dialog("close");// TODO: send an ajax order to delete all items

                //destino = '/pofecam/index.php/doc1_c/index/%20/' + $('#documento').val() + '/' + $('#plantilla').val() + '/true';
                destino = '/pofecam/index.php/doc1_c/index/' + $('#documento').val() + '/' + $('#plantilla').val() + '/' + $('#entidad').val() + '/true';
                //alert(destino);
                window.location.replace(destino);
            },
            "Cancelar": function ()
            {
                $(this).dialog("close");
            }
        }
    });

    $("#opener").click(function () {
        $("#dialog").dialog("open");
    });
});
function actualizar_status()
{
    actual = $('#boton_status').html();
    if (actual == 'No se ha subido ningún fichero.')
        return;
    $('#boton_status').html('El fichero que está actualmente en Archivo Digital, no está actualizado');
    $('#generar_button').prop('disabled', false);
}
function explotar_textarea(campo)
{
    $div = $('#' + campo + 'div');
    $div.css({"width": '100%', "height": '50%'})
    $textarea = $('#' + campo); // obtenemos el textarea a explotar
    $textarea.css({"width": '100%', "height": '500'})
    $("#accordion").accordion("refresh");
}
function actualizar_datadoc(ncampo, campo, id)
{
    entidad = $('#entidad').val();
    $textarea = $('#' + ncampo); // obtenemos el textarea a explotar
    $textarea.css({"width": '400', "height": '60'});
    var texto = $('#' + ncampo).val(); //Obtenemos el valor de la input
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/actualizar_datadoc', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + campo + '&id=' + id + '&contenido=' + texto + '&entidad=' + entidad //Pasaremos por parámetro POST el nombre y contenido del campo
    });
    actualizar_status();
}
function actualizar_datadoc_noexplode(ncampo, campo, id)
{
    entidad = $('#entidad').val();
    $textarea = $('#' + ncampo); // obtenemos el textarea a explotar
    var texto = $('#' + ncampo).val(); //Obtenemos el valor de la input
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/actualizar_datadoc', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + campo + '&id=' + id + '&contenido=' + texto + '&entidad=' + entidad//Pasaremos por parámetro POST el nombre y contenido del campo
    });
    actualizar_status();
}
function actualizar_datadoc_fecha(ncampo, campo, id)
{
    entidad = $('#entidad').val();
    texto = $('#' + ncampo).val(); //Obtenemos el valor de la input
    // alert('ncampo'+texto);
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/actualizar_datadoc', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + campo + '&id=' + id + '&contenido=' + texto + '&ncampo=' + ncampo + '&entidad=' + entidad//Pasaremos por parámetro POST el nombre y contenido del campo
    });
    actualizar_status();
}
function obtener_datadoc(campo, id)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/obtener_datadoc', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + campo + '&id=' + id, //Pasaremos por parámetro POST el nombre y contenido del campo
        success: function (resp) { //Cuando se procese con éxito la petición se ejecutará esta función
            $('#' + campo).html(resp);
        }
    });
}
function obtener_tabla(campo, id)
{
    entidad = $('#entidad').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/obtener_tabla', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + campo + '&id=' + id + '&entidad=' + entidad, //Pasaremos por parámetro POST el nombre y contenido del campo
        success: function (resp) { //Cuando se procese con éxito la petición se ejecutará esta función
            $('#tabla' + campo).html(resp);
        }
    });
}
function habilitable(id_campo, id_campo_txt, id, idcampo)
{
    $checkbox = $('#' + id_campo);    // tenemos el checkbox identificado
    $campo = $('#' + id_campo_txt);  // y el campo que hay que habilitar/deshabilitar
    if ($checkbox.is(':checked'))   // si la checkbox esta clicada
    {
        $campo.removeAttr("disabled"); // y si no, se quita la deshabilitacion
        hab = 'True'; // y si no, se quita la deshabilitacion
    } else
    {
        $campo.attr("disabled", true); // el campo de texto se deshabilita

        hab = 'False';
    }
    var texto = $campo.val(); //Obtenemos el valor de la input
    entidad = $('#entidad').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/actualizar_datadoc_habilitable', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + idcampo + '&id=' + id + '&contenido=' + texto + '&habilitado=' + hab + '&entidad=' + entidad //Pasaremos por parámetro POST el nombre y contenido del campo

    });
    actualizar_status();
}
function enable_disable_set(id_campo, idcampo, id)
{
    $checkbox = $('#' + id_campo);    // tenemos el checkbox identificado
    var campos = $('[depende =  ' + idcampo + ']'); //seleccionamos los elementos con dependencia
    entidad = $('#entidad').val();
    campos.each(function (habilitar) {
        if ($checkbox.is(':checked'))   // si la checkbox esta clicada
        {
            $(this).removeAttr("disabled"); // y si no, se quita la deshabilitacion
            hab = 'True';
        } else
        {
            $(this).attr("disabled", true); // el campo de texto se deshabilita
            hab = 'False';
        }
    }); // fin de foreach
    texto = '';
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/actualizar_datadoc_habilitable', //Realizaremos la petición al metodo actualizar_datadoc del controlador
        data: 'campo=' + idcampo + '&id=' + id + '&contenido=' + texto + '&habilitado=' + hab + '&entidad=' + entidad //Pasaremos por parámetro POST el nombre y contenido del campo
    });
    actualizar_status();
}
function variascolumnas(id_empresa, id_campo, id_columna, id_fila, id_tabla, depende_de, ncol)
{
    $campo = $('#' + id_campo + id_columna + id_fila);    // tenemos el campo seleccionado
    entidad = $('#entidad').val();
    var texto = $campo.val();  // en texto, tenemos el contenido
    $.ajax({
        type: 'POST',
        url: '/pofecam/doc1_c/actualizar_variascolumnas', //Realizaremos la petición al metodo actualizar del controlador
        data: 'id_empresa=' + id_empresa + '&entidad=' + entidad + '&id_campo=' + id_campo + '&id_columna=' + id_columna + '&id_fila=' + id_fila + '&id_tabla=' + id_tabla + '&depende_de=' + depende_de + '&contenido=' + texto,
        success: function (resp) { //Cuando se procese con éxito la petición se ejecutará esta función
            $('#' + id_tabla).html(resp);
            $('.datepicker').each(function () {
                $(this).datepicker();
            });

            id_columna++;
            if (id_columna == ncol)	  // hemos llegado a la ultima columna
            {
                id_columna = 0;
                id_fila++;	  // primera columna de la siguiente fila
            }
            id = id_campo + id_columna + id_fila;
            $('#' + id).focus();   // y lo enfocamos
        }
    });
    actualizar_status();

}
function togdiv(id_div, id_empresa)
{
    mi_div = $('#' + id_div); // handler del elemento div
    disp = mi_div.css('display');	// obtenemos el estado del div
    if (mi_div.attr('refresh') != undefined)	// this means that the attr is set
        obtener_tabla(mi_div.attr('refresh'), id_empresa);	// this have to set again the given field
    if (disp == 'block')	// si se esta mostrando
        mi_div.fadeOut('slow', function () {
            mi_div.css('display', 'none');
        });
    else
    {
        mi_div.fadeIn('slow', function () {
            mi_div.css('display', 'block');
        });
        setup_jtables(id_div, id_empresa);
        // test for the existence of a field to refresh
    }

}
function setup_jtables(id, id_empresa)// activa los elementos jtable del documento. es llamada al actvar la lista (boton mostrar/ocultar)
{
    elemento = $('#' + id);
    entidad = $('#entidad').val();
    elemento.jtable({
        title: 'Seleccion de elementos:',
        //paging: true, //Enable paging
        //pagesize: 10, //Set page size (default: 10)
        //sorting: true, //Enable sorting
        //defaultSorting: 'Name ASC', //Set default sorting
        selecting: true, //Enable selecting
        multiselect: true, //Allow multiple selecting
        selectingCheckboxes: true, //Show checkboxes on first column
        actions: {
            listAction: '/pofecam/doc1_c/listarfilas/' + id + '/' + id_empresa + '/' + entidad
                    // createAction: '/GettingStarted/CreatePerson',
                    // updateAction: '/GettingStarted/UpdatePerson',
                    // deleteAction: '/GettingStarted/DeletePerson'
        },
        fields: {
            id: {
                key: true,
                list: false
            },
            selected: {
                list: false
            },
            orden: {
                title: '#',
                width: '5%',
                create: false,
                edit: false
            },
            col0: {
                title: 'Texto',
                width: '95%',
                create: false,
                edit: false
            },
            col1: {
                title: 'Texto',
                width: '95%',
                create: false,
                edit: false
            },
            col2: {
                title: 'Texto',
                width: '95%',
                create: false,
                edit: false
            },
            col3: {
                title: 'Texto',
                width: '95%',
                create: false,
                edit: false
            },
            col4: {
                title: 'Texto',
                width: '95%',
                create: false,
                edit: false
            }
        },
        selectionChanged: function () {
            //Get all selected rows
            var $selectedRows = $('#' + id).jtable('selectedRows');
            var listafilas = '';
            entidad = $('#entidad').val();
            if ($selectedRows.length > 0) {
                $selectedRows.each(function ()
                {
                    var record = $(this).data('record');
                    if (listafilas == '')
                        listafilas = record.id;
                    else
                        listafilas = listafilas + "," + record.id;
                });

                $.ajax(
                        {
                            type: 'POST',
                            url: '/pofecam/doc1_c/actualizar_datadoc_lista_plus', //Realizaremos la petición al metodo actualizar_datadoc_lista del controlador
                            data: 'id_campo=' + id + '&id_empresa=' + id_empresa + '&entidad=' + entidad + '&array_texto=' + listafilas //Pasaremos por parámetro POST empresa, campo, y el id del texto a guardar
                        });
                actualizar_status();
            }


        },
        rowInserted: function (event, data) {
            if (data.record.selected == 1) {
                $('#' + id).jtable('selectRows', data.row);
            }
        }
    }
    );
    elemento.jtable('load');
}
function file_upload()
{
    //actual = $('#nodo_actual').val()
    //$('#current_folder').val(actual);
    //$('#file_upload_container').show();
    $('#file_upl').trigger('click');
    // $('#file_upload_submit').trigger('click');
}
function file_upload_submitfunction()
{
    actual = $('#nodo_actual').val();

    $('#file_upload_submit').trigger('click');
}
function generar_odt(documento, plantilla, entidad)
{
    $('#generar_button').prop('disabled', true);
    javascript: window.location = '/pofecam/index.php/doc1_c/generar_documento/' + documento + '/' + plantilla + '/' + entidad
}

    