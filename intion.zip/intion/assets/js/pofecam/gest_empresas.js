
$(function ()
{
    $("#tabs").tabs({
        activate: function (event, ui) {

        },
        heightStyle: "auto"
    });
    $("#status").buttonset();
    $("#preven_status").buttonset();
    $("#serpa_status").buttonset();
    $(document).tooltip({track: true});
    $("#empresas").validationEngine();
    $(".datepicker").datepicker();
    // datepicker yyyy-mm-dd format
    $(".datepicker").change(function () {
        $(this).datepicker("option", "dateFormat", "yy-mm-dd");
    });
    $(":input").change(function () {
        actualizar_campo($(this))
    });
    enfocar('tabs');

    $(window).on('beforeunload', function () {
        msg = chk_out();
        if (msg != '')
            return msg;
    });

})
function enfocar(elemento)
{
    focalizar = $("#" + elemento).position().top;
    $('html,body').animate({scrollTop: focalizar}, 1000);
}
function actualizar_campo(event)
{
    //$("#f_contrato").val($.datepicker.parseDate( "yy-mm-dd",$("#f_contrato").val()));
    if ($(event).prop('type') == 'checkbox')
        value = $(event).prop('checked');
    else
        value = $(event).val();
    campo = $(event).attr('id');

    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/gest_empresas_c/actualizar_campo', //the method in controller
        data: 'campo=' + campo + '&value=' + value,
        success: function (resp)
        {
            if (resp != '')
            {
                alert(resp);
                $(event).val('');
                $(event).focus();
                return;
            }
        }
    });
    if (campo == 'nombre')
        $('#empresa_activa').html(value + '<br><a href="/pofecam/pofecam/seleccionar_empresa" class="boton">Cambiar de empresa</a>');
    if (campo == 'tienecontrato' || campo == 'importe_actividades_tecnicas' || campo == 'precio')// have to set cliente_prevencion button
    {
        $('#cliente_prevencion').prop('checked', true);
        $.ajax({
            type: 'POST',
            url: '/pofecam/index.php/gest_empresas_c/actualizar_campo', //the method in controller
            data: 'campo=cliente_prevencion&value=true'
        });
    }
    if (campo == 'importe_vigilancia_salud' || campo == 'importe_reconocimiento')// have to set vigilancia de la salud button
    {
        $('#vs').prop('checked', true);
        $.ajax({
            type: 'POST',
            url: '/pofecam/index.php/gest_empresas_c/actualizar_campo', //the method in controller
            data: 'campo=vs&value=true'
        });
    }
    if (campo == 'cc_entidad' || campo == 'cc_sucursal' || campo == 'cc_cc')
    {
        calcular_dc();  // To be sure that dc field is re-calculated
        $.ajax({
            type: 'POST',
            url: '/pofecam/index.php/gest_empresas_c/actualizar_campo', //the method in controller
            data: 'campo=cc_dc' + '&value=' + $('#cc_dc').val()
        });
    }
}
function contratoclicked()  // disables numero_contrato input if enabled. If turns on, then there are two options: if there where numero_contrato acquired previously,
        // does nothing but enable input field. If the field is empty, check via ajax and take the next number available.
        {
            tienecontrato = $('#tienecontrato').prop('checked');
            // disable/enable input field
            $('#numero_contrato').prop('disabled', !tienecontrato);
            if (!tienecontrato)    // if disabled, it ends
                return;
            if ($.trim($('#numero_contrato').val()) != '')
                return;
            $.ajax({
                type: 'POST',
                url: '/pofecam/index.php/gest_empresas_c/obtener_siguiente_contrato', //the method in controller
                success: function (resp)
                {
                    $('#numero_contrato').val(resp);
                }
            })

        }
function actualizar_observaciones(id)
{
    texto = $('#obs' + id).val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/gest_empresas_c/actualizar_obs', //the method in controller
        data: 'id=' + id + '&texto=' + texto
    })
}
function insertar_observaciones(id)
{
    texto = $('#obs_nueva').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/gest_empresas_c/insertar_obs', //the method in controller
        data: 'texto=' + texto
    })
}
function copiacif()
{
    // take values from comp name/cif only if rep_legal is empty
    if ($('#r_legal_empresa_nif').val() == '')
        $('#r_legal_empresa_nif').val($('#cif').val());
    actualizar_campo($('#r_legal_empresa_nif'));
    if ($('#r_legal_empresa_nombre').val() == '')
        $('#r_legal_empresa_nombre').val($('#nombre').val());
    actualizar_campo($('#r_legal_empresa_nombre'));
}
function actualizar_cc()
{
    entidad = $('#cc_entidad').val();
    sucursal = $('#cc_sucursal').val();
    dc = $('#cc_dc').val();
    cc = $('#cc_cc').val();
    id_empresa = $('#id_empresa').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/gest_empresas_c/actualizar_cuenta', //the method in controller
        data: 'entidad=' + entidad + '&sucursal=' + sucursal + '&dc=' + dc + '&cc=' + cc + '&id_empresa=' + id_empresa,
        success: function (resp)
        {
            if (resp != '')
                alert(resp);
            else
                alert('La cuenta ha sido actualizada.');
        }
    });
}
function calcular_dc()
{
    entidad = $('#cc_entidad').val();
    sucursal = $('#cc_sucursal').val();
    cc = $('#cc_cc').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/gest_empresas_c/calcular_dc', //the method in controller
        data: 'entidad=' + entidad + '&sucursal=' + sucursal + '&cc=' + cc,
        success: function (resp)
        {
            $('#cc_dc').val(resp);
        }
    });
}
function letraDni(dni)
{
    var lockup = 'TRWAGMYFPDXBNJZSQVHLCKE';
    return lockup.charAt(dni % 23);
}
function calc_dni(campo, label)
{
    cadena = $('#' + campo).val();
    cadena = cadena.trim();
    if (isNaN(cadena.substring(0, 1)))   // the first char from left is not a number
        $('#' + label).html(''); // then, does nothing
    else
    {
        if (isNaN(cadena.substring(cadena.length - 1, cadena.length)))   // the last char is not a number
            //alert(cadena.substring(cadena.length-1,cadena.length));
            cadena = cadena.substring(0, cadena.length - 1)
        $('#' + label).html('<b>' + letraDni(cadena) + '</b>');
    }

}
function chk_out()
{
    errores = false;  // initially, there are no errors
    chk_cif = '';
    chk_name = '';
    if ($('#cif').val() == '')
        chk_cif = 'No se ha proporcionado un CIF para la empresa.\n ';
    if ($('#nombre').val() == '')
        chk_name = 'No se ha proporcionado un nombre para la empresa.'
    return chk_cif + chk_name;

}
function exportar(database)
{

    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/gest_empresas_c/exportar', //the method in controller
        data: 'database=' + database,
        success: function (resp)
        {
            if (resp == '')
                actualizar_cc();
            else
                alert(resp);
        }
    });


}