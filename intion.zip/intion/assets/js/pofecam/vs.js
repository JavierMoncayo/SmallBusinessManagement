$(function () {
    $(".datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        yearRange: "c-70:"
    });
    $(".datepicker_n").datepicker();
});
function clickall()
{
    var checked = $('#chkboxheader').prop('checked');
    $('.tr').prop('checked', checked);
}
function testdni()
{
    var lockup = 'TRWAGMYFPDXBNJZSQVHLCKE';
    dni = $('#dni').val();
    $('#letra').html('<b>' + lockup.charAt(dni % 23) + '</b>');
}
function salvar(campo)
{
    id_trabajador;    // if 0, the row is not created yet
    valor = $('#' + campo).val();
    id_trabajador = $('#id_trabajador').val()
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/actualizar_campo', //the method in controller
        data: 'id_trabajador=' + id_trabajador + '&campo=' + campo + '&valor=' + valor,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            actualizar(resp);
        }
    })
}
function salvardni()
{
    valor = $('#dni').val() + $('#letra').text();           // letter appended
    id_trabajador = $('#id_trabajador').val();
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/actualizar_campo', //the method in controller
        data: 'id_trabajador=' + id_trabajador + '&campo=dni&valor=' + valor,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            if (resp.error != '')
                alert(resp.error)
            $('#id_trabajador').val(resp.id);          // set the ajax response as new id for editing
            actualizar(resp);

        }
    })

}
function editar(id_trabajador)
{
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/obtener_trabajador', //the method in controller
        data: 'id_trabajador=' + id_trabajador,
        success: function (json_resp)
        {
            resp = JSON.parse(json_resp);
            $('#id_trabajador').val(resp.id);          // set the ajax response as new id for editing
            $('#dni').val(resp.dni);
            actualizar(resp);
            $('#dni').focus();

        }
    })
}
function actualizar_old(trabajador)
{
    $('#nombre').val(trabajador.nombre);
    $('#nombre').prop('disabled', false);
    $('#id_genero').val(trabajador.id_genero);
    $('#id_genero').prop('disabled', false);
    $('#numero_ss').val(trabajador.numero_ss);
    $('#numero_ss').prop('disabled', false);
    $('#f_nac').val(trabajador.f_nac);
    $('#f_nac').prop('disabled', false);
    $('#minusvalia').val(trabajador.minusvalia);
    $('#minusvalia').prop('disabled', false);
    $('#id_area_funcional').val(trabajador.id_area_funcional);
    $('#id_area_funcional').prop('disabled', false);
    $('#id_grupo_cotizacion').val(trabajador.id_grupo_cotizacion);
    $('#id_grupo_cotizacion').prop('disabled', false);
    $('#id_estudios').val(trabajador.id_estudios);
    $('#id_estudios').prop('disabled', false);
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/actualizar_trab', //the method in controller
        success: function (resp)
        {
            $('#col_trab').html(resp);
        }
    })
}
function actualizar(trabajador)
{
    $('#nombre').val(trabajador.nombre);
    $('#nombre').prop('disabled', false);
    $('#id_genero').val(trabajador.id_genero);
    $('#id_genero').prop('disabled', false);
    $('#numero_ss').val(trabajador.numero_ss);
    $('#numero_ss').prop('disabled', false);
    $('#f_nac').val(trabajador.f_nac);
    $('#f_nac').prop('disabled', false);
    $('#minusvalia').val(trabajador.minusvalia);
    $('#minusvalia').prop('disabled', false);
    $('#id_area_funcional').val(trabajador.id_area_funcional);
    $('#id_area_funcional').prop('disabled', false);
    $('#id_grupo_cotizacion').val(trabajador.id_grupo_cotizacion);
    $('#id_grupo_cotizacion').prop('disabled', false);
    $('#id_estudios').val(trabajador.id_estudios);
    $('#id_estudios').prop('disabled', false);
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/actualizar_trab', //the method in controller
        data: 'trabajador=' + trabajador.id,
        success: function (resp)
        {
            retorno = jQuery.parseJSON(resp);
            if ($('#tr' + retorno.id).length)        // the element does exist
            {
                $('#tr' + retorno.id).html(retorno.txt); // then, replace the content
            } else
            {
                $('#lista_trabajadores').append('<tr id="tr' + retorno.id + '">' + retorno.txt + '</tr>');
            }
        }
    })
}
function limpia()
{
    $('#nombre').val('');
    $('#nombre').prop('disabled', true);
    $('#id_genero').val(1);
    $('#id_genero').prop('disabled', true);
    $('#numero_ss').val('');
    $('#numero_ss').prop('disabled', true);
    $('#f_nac').val('');
    $('#f_nac').prop('disabled', true);
    $('#minusvalia').val('');
    $('#minusvalia').prop('disabled', true);
    $('#id_area_funcional').val(0);
    $('#id_area_funcional').prop('disabled', true);
    $('#id_grupo_cotizacion').val(0);
    $('#id_grupo_cotizacion').prop('disabled', true);
    $('#id_estudios').val(0);
    $('#id_estudios').prop('disabled', true);
    $('#dni').val('');
    $('#dni').focus();
    $('#id_trabajador').val('');
}
function emitir(quecosa)
{
    lista = 'fecha_factura=' + $('#fecha_factura').val() + '&fecha_reco=' + $('#fecha_reco').val() + '&precio_reco=' + $('#precio_reco').val();
    $('.tr').each(
            function ()
            {
                if ($(this).prop('checked'))
                    lista = lista + '&' + $(this).prop('id') + '=true';
            }
    );
    $.ajax({
        type: 'POST',
        url: '/pofecam/index.php/vs/' + quecosa, //the method in controller
        data: lista,
        success: function () {
            if (quecosa == 'sobres')
                window.location = 'vs/download';
            else
                alert('La factura ha sido generada.');
        }
    })


}
