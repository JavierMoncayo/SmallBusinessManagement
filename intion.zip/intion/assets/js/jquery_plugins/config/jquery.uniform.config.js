$(function () {
    $(".radio-uniform").uniform();
});