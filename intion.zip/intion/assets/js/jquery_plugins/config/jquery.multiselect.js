$(function () {
    $(".multiselect").multiselect();
});