<?php

class Warehouse_m extends CI_Model
{

  function __construct()
  {
    parent::__construct();
  }

  public function getProducts()
  {
    $sql = "SELECT id, name, id_family, id_category
            FROM products
            ORDER BY id_family";
// Return the consult as an object.
    return $this->db->query($sql)->result();
  }

  public function getProductName($id)
  {
    $sql = "SELECT name
            FROM products 
            WHERE id = $id";
    $data = array('query' => $this->db->query($sql)->result(),
        'id' => $id);
    return $data;
  }

  public function getCustomers()
  {
    $sql = "SELECT id, name 
            FROM customers 
            WHERE active 
            ORDER BY name";
// Return the consult as an object.
    return $this->db->query($sql)->result();
  }

  public function getCustomerId($customerName)
  {
    $sql = "SELECT id 
            FROM customers 
            WHERE name = '$customerName'";

// Return the consult as an object.
    return $this->db->query($sql)->row()->id;
  }

  public function getCustomerName($id)
  {
    $sql = "SELECT name 
            FROM customers
            WHERE id = $id";
// Return the consult as an object.
    return $this->db->query($sql)->result();
  }

  public function getProductsAvailables()
  {
    $sql = "
          SELECT DISTINCT  id_product, name,
            (SELECT COUNT(*) FROM warehouse WHERE id_product = products.id AND NOT delivered) as stock
          FROM products
          INNER JOIN warehouse ON (warehouse.id_product = products.id)
          ORDER BY id_family
";
    return $this->db->query($sql)->result();
    /*
     * Este modelo debe recuperar una lista con los ID_PRODUCT y los ID de WAREHOUSE
     *  de los productos disponibles para entregar junto con el nombre de los mismos 
     *  y el numero maximo de unidades que hay para entregar.
     */
  }

  public function getStockCustomer($id)
  {
    // Seleccionar de warehouse los productos que delivered = 1 y id_customer = $id
    $sql = " SELECT warehouse.id, warehouse.id_product, warehouse.date_delivery, 
                    warehouse.date_delivery, products.name, warehouse.id_product AS ref_product,
                      ( SELECT COUNT(*) FROM warehouse 
                        WHERE id_customer = $id 
                          AND ref_product = warehouse.id_product 
                          AND NOT sale
                      ) AS numberUds
             FROM warehouse
             JOIN products ON products.id = warehouse.id_product
             WHERE id_customer = $id AND NOT sale 
             GROUP BY warehouse.id_product
             ORDER BY date_delivery";
    return $this->db->query($sql)->result();
  }

  public function saveOrder($data)
  {
    $sql = "INSERT INTO warehouse (id_product, date_in, price_cost) VALUES ";
    $cadena = "";
    for ($i = 0; $i < $data[3]; $i++)
    {
      $add = " ($data[0], '$data[1]', $data[2]),";
      $sql = $sql . $add;
    }
    //var_dump($sql);
    //die;
    $sql = trim($sql, ',');
    $this->db->query($sql);
  }

  public function saveDelivery($products, $customer, $date, $numberUds)
  {
    $j = 0;
    foreach ($products as $current)
    {
      for ($i = 0; $i < $numberUds[$j]; $i++)
      {
        //  echo "Unidad numero: $i de un total de $numberUds[$j]<br>";
        $sql = " SELECT id FROM warehouse 
               WHERE id_product = $current AND NOT delivered 
               ORDER BY date_in 
               LIMIT 1";
        $id = $this->db->query($sql)->row()->id;
        $sql = "
        UPDATE warehouse
        SET id_customer = $customer, date_delivery = '$date', delivered = 1
        WHERE id = $id";
        $this->db->query($sql);
      }
      $j++;
    }
  }

  public function saveSale($products, $numberUds, $prices, $date, $customer)
  {
    // EL FUNKING problem aqui es como hacer para que se repita 
    $i = 0;
    foreach ($products as $current)
    {
      $sql = "UPDATE warehouse
              SET price_sale =$prices[$i], date_sale = '$date', sale = 1
              WHERE id_product = $products[$i] 
                  AND id_customer = $customer 
                  AND NOT sale 
              LIMIT $numberUds[$i]";
      $i++;
      $this->db->query($sql);
    }
  }

  public function deactivateCustomer($idCustomer)
  {
    /**
     * Aqui hay que desactivar el cliente en la tabla "customers" en la tabla
     *  warehouse hay que poner los productos asignados al tipo como disponibles.
     */
    $sql = "UPDATE warehouse SET delivered = FALSE, date_delivery = NULL, id_customer = NULL 
            WHERE id_customer = $idCustomer AND NOT SALE";
    $this->db->query($sql);
    $sql = "UPDATE customers SET active = FALSE WHERE id = $idCustomer";
    $this->db->query($sql);
  }

  public function setDirectSale($products, $dateDelivery, $numberUds)
  {
    $idCustomer = 10; // Mi ID

    $i = 0;
    foreach ($products as $current)
    {
      $sql = "UPDATE warehouse
              SET price_sale =$prices[$i], date_sale = '$date', sale = 1
              WHERE id = $current";
      $i++;
      $this->db->query($sql);
    }
  }

  public function returnProduct($idProduct)
  {
    $sql = "UPDATE warehouse SET delivered = FALSE, date_delivery = NULL, id_customer = NULL 
            WHERE id = $idProduct AND NOT SALE";
    $this->db->query($sql);
  }

}
