<?php

class Catalogue_m extends CI_Model
{

  function __construct ()
  {
    parent::__construct ();
  }

  public function getInformation ()
  {
    $data = new stdClass();

    $data->familias = $this->getFamilies ();
    $data->subfamilias = $this->getSubfamilies ();


    return $data;
  }

  private function getFamilies ()
  {
    $sql = "SELECT familia, count(*) AS units FROM Products GROUP BY familia";
    return $this->db->query ($sql)->result ();
  }

  private function getSubfamilies ()
  {
    $data = array('subfamilia', 'subfamilia2', 'subfamilia3', 'subfamilia4');
    $summary = new stdClass();
    foreach ($data as $current)
    {
      $sql = "SELECT $current, count(*) AS units FROM Products GROUP BY $current";
      echo $sql;

      $summary->$current = $this->db->query ($sql)->result ();
    }
    die;
    return $summary;
  }

}
