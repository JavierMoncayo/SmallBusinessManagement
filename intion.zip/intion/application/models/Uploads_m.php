<?php

class Uploads_m extends CI_Model
{

  function __construct()
  {
    parent::__construct();
  }

  public function setImageData($data)
  {
  //"INSERT INTO warehouse (id_product, date_in, price_cost) VALUES 
    $sql =" INSERT INTO pictures (name, storageName, relativePath) 
            VALUES ('$data->name','$data->storageName','$data->relativePath')";
    $this->db->query($sql);
  }

}
