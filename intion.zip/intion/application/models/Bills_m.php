<?php

class Bills_m extends CI_Model
{

  private $dEnd;
  private $dStart;

  function __construct()
  {
    parent::__construct();
  }

  /**
   * @brief This method provides all the information related with stocks, sales...
   * @details The information about stock is the stock you have, delivered stock  and the value of each one.
   *          About sales the method provide a summary of sales grouped by customers and grouped by products
   * @param type $startDate The earlier date you want to check
   * @param type $endDate The oldest date you want to check
   * @return \stdClass Collection of results order by theme.
   */
  public function getGeneralSummary($startDate, $endDate)
  {
    $this->dEnd = $endDate;
    $this->dStart = $startDate;

    $results = new stdClass();

    $results->totalStock = $this->getTotalStock();
    $results->deliveredStock = $this->getDeliveredStock();

    $results->totalSales = $this->getSales();

    $results->salesSummary = $this->getSalesSummary();
    $results->customerSummary = $this->getCustomerSummary();
    $results->productsSummary = $this->getProductsSummary();
    
    return $results;
  }

  private function getTotalStock()
  {
    /* ##################################################################################
     *      Aqui he quitado toda considesarcion con fechas.
     * ##################################################################################
     */
    $sql = "SELECT sum(price_cost) AS totalCost, COUNT(*) AS totalUnits
            FROM warehouse
            WHERE NOT sale";
    return $this->db->query($sql)->row();
  }

  /* ##################################################################################
   *          FUNCIONES PARA EL RESULMEN GENERAL DE STOCK
    ################################################################################## */

  private function getDeliveredStock()
  {
    /* ##################################################################################
     *      
     * ##################################################################################
     */
    $sql = "SELECT sum(price_cost) AS totalCost, COUNT(*) AS totalUnits
      FROM warehouse
      WHERE delivered 
            AND NOT sale
            AND date_delivery >= '$this->dStart'
            AND date_delivery < '$this->dEnd'";

//    $sql = "SELECT sum(price_cost) AS totalCost, COUNT(*) AS totalUnits
//            FROM warehouse
//            WHERE delivered AND NOT sale";
    return $this->db->query($sql)->row();
  }

  private function getSales()
  {
    /*     * ##################################################################################
     * Aqui acabo de cambiar las fechas de la condicion del query. Antes estaban
     *  "date_delivery" y lo he cambiado por "dates_sale"
     * ##################################################################################
     */
    $sql = "SELECT sum(price_sale) AS totalSale, COUNT(*) AS totalUnits
            FROM warehouse
            WHERE sale AND date_sale >= '$this->dStart'
                       AND date_sale < '$this->dEnd'";
    return $this->db->query($sql)->row();
  }

  /* ##################################################################################
   *          FUNCIONES PARA EL RESULMEN GENERAL DE VENTAS
    ################################################################################## */

  private function getSalesSummary()
  {
    /* ##################################################################################
     * Aqui acabo de cambiar las fechas de la condicion del query. Antes estaban
     *  "date_delivery" y lo he cambiado por "dates_sale"
     * ##################################################################################
     */
    $sql = " SELECT count(id) AS totalUnits, sum(price_sale) AS priceSale, 
                    sum(price_cost) AS priceCost, (sum(price_sale)-sum(price_cost)) AS benefits
             FROM warehouse
             WHERE sale AND date_sale >= '$this->dStart'
                        AND date_sale < '$this->dEnd'";
    return $this->db->query($sql)->row();
  }

  /* ##################################################################################
   *          FUNCIONES PARA EL RESULMEN DE VENTAS POR CLIENTES
    ################################################################################## */

  private function getCustomerSummary()
  {
    /* ##################################################################################
     *      En el resumen de venta por clientes hay que considerar las fehas de venta
     * ##################################################################################
     */

    $sql = "SELECT id_customer, sum(price_sale) AS sales, 
              sum(price_cost) AS costs, 
              COUNT(id_product) AS unitsSold, 
              customers.name AS name,
              DATEDIFF(date_sale,date_delivery) AS time
            FROM warehouse
              JOIN customers ON(warehouse.id_customer = customers.id)
            WHERE sale AND date_sale >= '$this->dStart'
                       AND date_sale < '$this->dEnd'
            GROUP BY id_customer
            ORDER BY sales DESC";

    return $this->db->query($sql)->result();
  }

  private function getProductsSummary()
  {
    /* ##################################################################################
     *      Al considerar el resumen por productos de ventas hay que ver las fechas de venta.
     * ##################################################################################

     */

    $sql = "SELECT id_product, sum(price_sale) AS sales, 
              sum(price_cost) AS costs, 
              COUNT(id_product) AS unitsSold, 
              products.name AS name
            FROM warehouse
              JOIN products ON(warehouse.id_customer = products.id)
            WHERE sale AND date_sale >= '$this->dStart'
                       AND date_sale < '$this->dEnd'
            GROUP BY name
            ORDER BY unitsSold DESC";

    return $this->db->query($sql)->result();
  }


}
