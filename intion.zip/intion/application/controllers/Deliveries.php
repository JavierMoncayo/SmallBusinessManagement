<?php

if (!defined('BASEPATH'))
{
  exit('No direct script access allowed');
}

class Deliveries extends CI_Controller
{

  private $warehouse;
  private $defaultTemplate = 'deliveries/index';

  public function __construct()
  {
    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->model('Warehouse_m');
    $this->warehouse = new Warehouse_m();
  }

  public function My_output($template = null, $output = null)
  {
    $this->load->view('top');

    if (is_null($template))
    {
      $this->load->view($this->defaultTemplate, $output);
    } else
    {
      $this->load->view($template, $output);
    }
    $this->load->view("footer");
  }

  public function index()
  {
    // Por ahora no debe hacer nada mas que enseñarme las cosas que hay.
    $this->newDelivery();
    //$this->_output (null, $output);
  }

  public function newDelivery()
  {
    // Obtener nombre de los clientes y su identificador.
    $customers = $this->warehouse->getCustomers();
    //Obtener listado de productos disponibles:
    $products = $this->warehouse->getProductsAvailables();

    $output = array('customer' => $customers,
        'products' => $products);
    /*
     * 1- Ahora habria que recuperar las unidades máximas de cada uno de 
     *    los productos que el cliente puede quedarse en este pedido.
     * 
     * 2- Generar un listado de productos (Ya esta hecho en "DELIVERIES/NEWDELIVERY"
     * 
     * 3- Con la function "setDelivery()" comprobar el valor de los checkbox
     *    y utilizar el modelo para actualizar la base de datos.
     */
    $this->My_output('deliveries/newDelivery', $output);
  }

  public function setDelivery()
  {

    $this->warehouse->saveDelivery($_POST['products'], $_POST['customer'], $_POST['dateDelivery'], $_POST['numberUds']);
    $this->newDelivery();
  }

}
