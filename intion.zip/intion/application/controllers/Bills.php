<?php

if (!defined('BASEPATH'))
{
  exit('No direct script access allowed');
}

class Bills extends CI_Controller
{

  public $bills;
  private $defaultTemplate = 'bills/index';

  public function __construct()
  {
    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->model("Bills_m");
    $this->bills = new Bills_m();
  }

  public function My_output($template = null, $output = null)
  {
    $this->load->view('top');

    if (is_null($template))
    {
      $this->load->view($this->defaultTemplate, $output);
    } else
    {
      $this->load->view($template, $output);
    }
    $this->load->view('footer');
  }

  public function index()
  {
    $this->My_output(NULL, NULL);
  }

  public function showBills($startDate, $endDate)
  {
    $output = $this->bills->getGeneralSummary($startDate, $endDate);
    $this->load->view('bills/showBills', $output);
  }

}
