<?php

if (!defined('BASEPATH'))
{
  exit('No direct script access allowed');
}

class Sales extends CI_Controller
{

  private $warehouse;
  private $defaultTemplate = 'sales/index';

  public function __construct()
  {
    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->model('Warehouse_m');
    $this->warehouse = new Warehouse_m();
  }

  public function My_output($template = null, $output = null)
  {
    $this->load->view('top');
    if (is_null($template))
    {
      $this->load->view($this->defaultTemplate, $output);
    } else
    {
      $this->load->view($template, $output);
    }
    $this->load->view("footer");
  }

  public function index()
  {
    $this->My_output(null, $this->getActiveCustomers());
  }

  public function getstockCustomer($idCustomer = NULL)
  {
    if (is_null($idCustomer)){
      $idCustomer = $this->input->post('idCustomer');
    }
    $stock = $this->warehouse->getStockCustomer($idCustomer);
    $customer = $this->warehouse->getCustomerName($idCustomer);

    $output = array('stock' => $stock,
        'customer' => $customer[0],
        'idCustomer' => $idCustomer);
    $this->load->view('sales/setSale', $output);
    /*
     * 1- Ahora habria que recuperar las unidades máximas de cada uno de 
     *    los productos que el cliente puede quedarse en este pedido.
     * 
     * 2- Generar un listado de productos (Ya esta hecho en "DELIVERIES/NEWDELIVERY"
     * 
     * 3- Con la function "setDelivery()" comprobar el valor de los checkbox
     *    y utilizar el modelo para actualizar la base de datos.
     */
  }

  public function setSale()
  {
    $idCustomer = $this->warehouse->getCustomerId($_POST['customerName']);
    $this->warehouse->saveSale($_POST['products'],$_POST['numberUds'], $_POST['prices'], $_POST['date_sale'],$idCustomer);
    $this->index();
  }

  public function directSale()
  {
    $customer = $this->warehouse->getCustomerName(10); //Yo tengo ese ID.
    $products = $this->warehouse->getProductsAvailables();

    $output = array('customer' => $customer,
        'products' => $products);
    $this->My_output('sales/directSale', $output);
  }

  public function setDirectSale()
  {
    
    $this->warehouse->saveDelivery($_POST['products'], 10, $_POST['dateDelivery'], $_POST['numberUds'], $_POST['prices'], $idCustomer);
    $this->directSale();
  }

  public function deactivateCustomer()
  {
    $this->warehouse->deactivateCustomer($this->input->post('idCustomer'));
    $this->load->view($this->defaultTemplate, $this->getActiveCustomers());
  }

  public function returnProduct()
  {

    $this->warehouse->returnProduct($this->input->post('idProduct'));
    
    $this->getstockCustomer($this->input->post('idCustomer'));
  }

  private function getActiveCustomers()
  {
    $customers = $this->warehouse->getCustomers();
    return array('customer' => $customers);
  }

}
