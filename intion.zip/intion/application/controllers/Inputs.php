<?php

if (!defined('BASEPATH'))
{
  exit('No direct script access allowed');
}

class Inputs extends CI_Controller
{

  private $defaultTemplate = "inputs/index";
  private $crud;

  public function __construct()
  {
    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->library('grocery_CRUD');
    $this->crud = new Grocery_CRUD();
    $this->crud->set_theme('datatables');
  }

  public function My_output($template = null, $output = null)
  {
    $this->load->view("top");
    if (is_null($template))
    {
      $this->load->view($this->defaultTemplate, $output);
    } else
    {
      $this->load->view($template, $output);
    }
    $this->load->view("footer");
  }

  public function index()
  {
    $this->My_output(null, (object) array('output' => '', 'js_files' => array(), 'css_files' => array()));
  }

  public function productInput()
  {
    // Set table.
    $this->crud->set_table('products');
    // Set relation between tables.
    $this->crud->columns('thumbnail', 'name', 'reference', 'id_family', 'id_category', 'comment');
    $this->crud->set_relation('id_family', 'families', 'name');
    $this->crud->set_relation('id_category', 'categories', 'name');
    $this->crud->set_relation('id_picture', 'pictures', 'name');
    // Set fields to edit and add action:
    $this->crud->add_fields('id_family', 'id_category', 'name', 'url', 'model', 'comment');
    $this->crud->edit_fields('id_family', 'id_category', 'name', 'url', 'model', 'comment');
    // Set action to calculate reference before update or add a product.
    $this->crud->callback_before_insert(array($this, 'setReference'));
    $this->crud->callback_before_update(array($this, 'setReference'));
    // Change name to show columns to user
    $this->crud->display_as('id_family', 'Familia');
    $this->crud->display_as('id_category', 'Categoria');
    $this->crud->display_as('id_picture', 'Miniatura  ');
    // Render
    $this->My_output(null, $this->crud->render());
  }

  public function categoryInput()
  {
    // Set table.
    $this->crud->set_table('categories');
    // Set names to show columns
    $this->crud->display_as('name', 'Category name');
    $this->crud->display_as('comment', 'Comment');
    // Render
    $this->My_output(null, $this->crud->render());
  }

  public function familyInput()
  {
    // Set table.
    $this->crud->set_table('families');
    // Set names to show columns
    $this->crud->display_as('name', 'Family name');
    $this->crud->display_as('comment', 'Comment');
    // Render
    $this->My_output(null, $this->crud->render());
  }

  public function customerInput()
  {
    // Set table.
    $this->crud->set_table('customers');
    // Set names to show columns
    $this->crud->display_as('name', 'Nombre tienda');
    $this->crud->display_as('person', 'Nombre persona');
    $this->crud->display_as('address', 'Direccion');
    $this->crud->display_as('city', 'poblacion');
    $this->crud->display_as('phone', 'Fijo');
    $this->crud->display_as('mobile_phone', 'Movil');
    $this->crud->display_as('email', 'Email');
    $this->crud->columns(array('name', 'person', 'phone', 'mobile_phone', 'address', 'email'));
    // Render
    $this->My_output(null, $this->crud->render());
  }

  function setReference($post_array)
  {
    echo "HOLA ESTOY AQUI";
    var_dump($post_array);
  }

}
