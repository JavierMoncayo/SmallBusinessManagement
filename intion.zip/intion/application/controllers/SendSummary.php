<?php

if (!defined('BASEPATH'))
{
  exit('No direct script access allowed');
}

class SendSummary extends CI_Controller
{

  public $bills;
  private $defaultTemplate = 'bills/index';

  public function __construct()
  {
    parent::__construct();

    $this->load->database();
    $this->load->helper('url');
    $this->load->model("Bills_m");
    $this->bills = new Bills_m();
  }

  public function My_output($template = null, $output = null)
  {
    $this->load->view('top');

    if (is_null($template))
    {
      $this->load->view($this->defaultTemplate, $output);
    } else
    {
      $this->load->view($template, $output);
    }
    $this->load->view('footer');
  }

  public function index()
  {
    
    $this->load->library('email');

    $this->email->from('javier.gonzalezmoncayo@gmail.com', 'Your Name');
    $this->email->to('javimoncayo@prevecam.es');
    $this->email->cc('another@another-example.com');
    $this->email->bcc('them@their-example.com');

    $this->email->subject('Email Test');
    $this->email->message('Testing the email class.');

    $this->email->send();

    echo $this->email->print_debugger();
  }

}
