<?php

class Uploads extends CI_Controller
{

  public $updateModel;
  private $defaultTemplate = 'uploads/index';

  public function __construct()
  {
    parent::__construct();

    $this->load->database();
    $this->load->helper(array('form', 'url'));
    $this->load->model('Uploads_m');
    $this->updateModel = new Uploads_m();
  }

  public function My_output($template = null, $output = null)
  {
    $this->load->view('top');

    if (is_null($template))
    {
      $this->load->view($this->defaultTemplate, $output);
    } else
    {
      $this->load->view($template, $output);
    }
    $this->load->view('footer');
  }

  public function index()
  {
    $this->My_output(NULL, array('error' => ' '));
  }

  // Este metodo deberia ejecutarse por JS
  public function do_upload()
  {
    $config['upload_path'] = 'uploads';
    $config['allowed_types'] = 'gif|jpg|png|csv|xml';
    $config['overwrite'] = 'TRUE';
    $config['remove_spaces'] = 'TRUE';
    
    $this->load->library('upload', $config);
    $this->upload->initialize($config);

    if (!$this->upload->do_upload())
    {
      $error = array('error' => $this->upload->display_errors());

      $this->load->view('uploads/index', $error);
    } else
    {
      $data = $this->upload->data();

      $updateData = new stdClass();
      $updateData->name = $data['file_name'];
      $updateData->storageName = uniqid();
      $data['file_name'] = $updateData->storageName;
      $updateData->relativePath = $data['file_path'];
    
      $this->updateModel->setImageData($updateData);
      $this->index();
    }
  }

}
