<?php

class Catalogue extends CI_Controller
{

  public $updateModel;
  private $defaultTemplate = 'uploads/index';
  public $information;

  public function __construct ()
  {
    parent::__construct ();

    $this->load->database ();
    $this->load->helper ('url');
    $this->load->model ('Catalogue_m');
    $this->information = new Catalogue_m();
  }

  public function My_output ($template = null, $output = null)
  {
    $this->load->view ('top');

    if (is_null ($template))
    {
      $this->load->view ($this->defaultTemplate, $output);
    }
    else
    {
      $this->load->view ($template, $output);
    }
    $this->load->view ('footer');
  }

  public function index ()
  {
    $xml = "/var/www/html/intion/uploads/prueba1.xml";
    $csv = "/var/www/html/intion/uploads/GRACIA.csv";

    //$this->readCSV ($csv);
    //$this->readXML ($xml);
    $this->data();
  }

  public function data ()
  {

    $data = $this->information->getInformation();
    
    $this->My_output('catalogueInformation', $data);
  }

  /**
   * 
   * @param type $path Path to the csv file.
   */
  public function readCSV ($path)
  {
    echo "$path<br>";
    $file = fopen ($path, "w+");
    $list = array
        (
        "CACACA,Griffin,BLABLA BLA,Oslo,Norway",
        "CACACA,Quagmire,Oslo,Norway",
    );

    $file = fopen ($path, "w+");

    foreach ($list as $line)
    {
      fputcsv ($file, explode (',', $line));
    }

    fclose ($file);
  }

  public function readXML ($path)
  {
    $xml = simplexml_load_file ($path) or die ("Error: Cannot create object");

    $nodes = array(
        'codigo',
        'familia',
        'subfamilia',
        'subfamilia2',
        'subfamilia3',
        'subfamilia4',
        'ean',
        'talla',
        'hashtalla',
        'descripcion',
        'descripcionori',
        'novedad',
        'promocion',
        'video',
        'reponer',
        'grupo',
        'precio_recomendado',
        'precio_comercio_a',
        'precio_comercio_b',
        'precio_comercio_c',
        'precio_comercio_d',
        'iva',
        'explicacion',
        'explicacion_texto',
        'stock_disponible',
        'fabricante',
        'imagen_bu',
        'imagen_gr',
        'imagenes_lg',
        'imagenes_lp',
        'categorias',
        'fecha_descatalogado',
        'descatalogado');
    $comillas = array(
        'familia',
        'subfamilia',
        'subfamilia2',
        'subfamilia3',
        'subfamilia4',
        'talla',
        'hashtalla',
        'descripcion',
        'descripcionori',
        'explicacion',
        'explicacion_texto',
        'fabricante',
        'imagen_bu',
        'imagen_gr',
        'imagenes_lg',
        'imagenes_lp',
        'categorias',
        'fecha_descatalogado'
    );
    $values = '';


    foreach ($xml->ArticulosD->ArticuloD as $current)
    {
      foreach ($nodes as $nodeToCheck)
      {
//        if (in_array($nodeToCheck, $comillas))
//        {
        $values = $values . ',' . '"' . $this->db->escape_str ($current->$nodeToCheck) . '"';
//        } else
//        {
//          if ($current->$nodeToCheck == "")
//          {
//            $current->$nodeToCheck = 0;
//          }
//          $values = $values . ',' . $this->db->escape_str($current->$nodeToCheck);
//        }
      }
      $values = trim ($values, ',');

      $values = '(' . $values . ')';
      $sql = "INSERT INTO Products VALUES " . $values;

      $this->db->query ($sql);

      $values = '';
    }
    echo "FANTASTICO !!!!!";
  }

}
