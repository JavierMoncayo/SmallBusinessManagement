<?php

class Templates extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        //$this->load->database();
        $this->load->helper('url');
        $this->load->library('Phpodex');
    }

    public function index()
    {
        $phpOdex = new Phpodex();
        $template = "/var/www/html/intion/application/templates/PRUEBAS_LOPD.odt";

        $phpOdex->open($template);
        echo "open";
        $data = array("nombreEmpresa" => "Prueba 1");
        $phpOdex->fillRecord($data);

        //De esta manera se rellena la tabla contenida en el bloque con tantas
        //      filas como elementos tenga el array "TABLA1"
        $tableData = array(
            "bloque2" => array(
//                "nombreResponsableCopiasSeguridad" => "Name1",
//                "apellidosResponsableCopiasSeguridad" => "Surname1",
                "Tabla1" => array(
                    array(
                        "nombreResponsableCopiasSeguridad" => "Name1",
                        "apellidosResponsableCopiasSeguridad" => "Surname1"
                    ),
                    array(
                        "nombreResponsableCopiasSeguridad" => "Name2",
                        "apellidosResponsableCopiasSeguridad" => "Surname2"
                    ),
                    array(
                        "nombreResponsableCopiasSeguridad" => "Name3",
                        "apellidosResponsableCopiasSeguridad" => "Surname3"
                    )
                ),
            )
        );


        $phpOdex->fillBlock("bloque2", $tableData);

        //################################################################
        //      Rellenar cabecera / pie de pagina.
//        $phpOdex->setMode(Phpodex::MODE_HEADER_FOOTER);
//        $phpOdex->fillRecord($data);
        //################################################################

        $phpOdex->close("/var/www/html/intion/application/tmp/PRUEBAS_LOPD.odt");
        echo "<br>done";
//        "tabla1" => array(
//                array(
//                    "nombreResponsableCopiasSeguridad" => "Name1",
//                    "apellidosResponsableCopiasSeguridad" => "Surname1"
//                ),
//                array(
//                    "nombreResponsableCopiasSeguridad" => "Name2",
//                    "apellidosResponsableCopiasSeguridad" => "Surname2"
//                ),
//                array(
//                    "nombreResponsableCopiasSeguridad" => "Name3",
//                    "apellidosResponsableCopiasSeguridad" => "Surname3"
//                )
//            )
    }

}
