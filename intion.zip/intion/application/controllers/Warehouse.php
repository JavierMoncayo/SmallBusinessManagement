<?php

if (!defined ('BASEPATH'))
{
  exit ('No direct script access allowed');
}

class Warehouse extends CI_Controller
{

  private $warehouse;
  private $defaultTemplate = 'warehouse/index';

  public function __construct ()
  {
    parent::__construct ();

    $this->load->database ();
    $this->load->helper ('url');
    $this->load->model ('Warehouse_m');
    $this->warehouse = new Warehouse_m();
  }

  public function My_output ($template = null, $output = null)
  {
    $this->load->view ('top');
    if (is_null ($template))
    {
      $this->load->view ($this->defaultTemplate, $output);
    }
    else
    {
      $this->load->view ($template, $output);
    }
    $this->load->view ("footer");
  }

  public function index ()
  {
    $products = $this->warehouse->getProducts ();
    //var_dump($products);
    $output = array('output' => $products);
    $this->My_output (null, $output);
  }

  public function setNewOrder ()
  {
    $id = $this->input->post ('idProduct');
    $data = $this->warehouse->getProductName ($id);
    $this->load->view ('warehouse/newOrder', array('output' => $data));
  }

  public function saveNewOrder ()
  {
    $data = array($this->input->post ('id'), $this->input->post ('dateIn'),
        $this->input->post ('priceIn'), $this->input->post ('nUnits'));
    $this->warehouse->saveOrder ($data);
    $this->index ();
  }

}
