<br>
<div id="left">
  <div id="code">
    <h2>How to: Como poner referencias de cosas.</h2>	
  </div>

  <br>
  <table border="0">
    <thead>
      <tr>
        <th>Familia del producto</th>
        <th>Atributo</th>
        <th>Referencia</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Star Wars</td>
        <td>--------</td>
        <td><strong>
            SW_(nombre)
          </strong></td>
      </tr>
      <tr>
        <td>Llaves de coches</td>
        <td>Silicona</td>
        <td><strong>
            CO_(Marca)_SI
          </strong></td>
      </tr>
      <tr>
        <td>Llaves de coches</td>
        <td>Imitacion</td>
        <td><strong>
            CO_(Marca)_IM
          </strong></td>
      </tr>
      <tr>
        <td>Futbol</td>
        <td>--------</td>
        <td><strong>
            FU_(nombreEquipo)
          </strong></td>
      </tr>
      <tr>
        <td>Minion</td>
        <td>--------</td>
        <td><strong>
            MI_(nombre)
          </strong></td>
      </tr>
      <tr>
        <td>Frutas</td>
        <td>--------</td>
        <td><strong>
            FR_(nombre)
          </strong></td>
      </tr>
      <tr>
        <td>Helados</td>
        <td>--------</td>
        <td><strong>
            HE_(nombre)
          </strong></td>
      </tr>
      <tr>
        <td>Auriculares</td>
        <td>Minions</td>
        <td><strong>
            AU_MI_(nombre)
          </strong></td>
      </tr>
      <tr>
        <td>Auriculares</td>
        <td>Superheroes</td>
        <td><strong>
            AU_SU_(nombre)
        </td>
      </tr>
    </tbody>
  </table>
</div>