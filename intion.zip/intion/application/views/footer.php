    <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo (ENVIRONMENT === 'development') ? 'Intion group  &#174 <strong>' . CI_VERSION . '</strong>' : '' ?></p>
  </body>
</html>