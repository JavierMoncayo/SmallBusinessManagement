<script>
  function SwapState(chkBox, NumberUds)
  {
      document.getElementById(NumberUds).disabled = !document.getElementById(chkBox).checked;
  }
</script>

<form method="post" action="setDelivery">
    <div id="left" >    
        <table border="0">
            <thead>
                <tr>
                    <th></th>
                    <th>Seleccionar cliente</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customer as $current): ?>
                  <tr>
                      <td onmouseover="" style="cursor: pointer;">
                          <input type="radio" name="customer" value="<?php echo $current->id ?>" required>
                      </td>
                      <td>
                          <?php echo $current->name ?>
                      </td>
                  </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div id="middle1">
        <table border="0">
            <thead>
                <tr>
                    <th></th>
                    <th></th>
                    <th>Seleccionar productos</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($products as $current):

                  if ($current->stock == 0)
                  {
                    $check = "disabled";
                    $color = "bgcolor='#e6e6e6'";
                  }
                  else
                  {
                    $check = "enabled";
                    $color = "bgcolor='#FFFFFF'";
                  }
                  ?>
                  <tr <?php echo $color ?>>
                      <td>
                          <input type="checkbox" name="products[]" 
                                 value="<?php echo $current->id_product ?>" <?php echo $check ?>
                                 id ='<?php echo $current->id_product ?>'
                                 onchange="SwapState('<?php echo $current->id_product ?>', '<?php echo ($current->id_product . 'U') ?>')"
                                 > 
                      </td>
                      <td>
                          <input style="width: 35px;" type="number" 
                                 step="1" min ="1" max="<?php echo $current->stock ?>"
                                 id ="<?php echo ($current->id_product . 'U') ?>"
                                 name="numberUds[]" value="1" disabled>
                      </td>
                      <td>
  <?php echo $current->name ?>  (<?php echo $current->stock ?>)
                      </td>
                  </tr>
<?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div id="middle2">
        <input type="date" name="dateDelivery" required value="<?php echo date ('Y-m-d'); ?>">
        <br><br><br>
        <button type="submit" value='deliveries/setDelivery' name ="id" >Nueva entrega</button>
    </div>
</form>
