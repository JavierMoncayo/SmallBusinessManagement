<div id="left">
  <table border="0">
    <thead>
      <tr>  
        <th>Seleccionar cliente</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($output as $current): ?>
      <form method="post" action="Deliveries/getCustomer">
        <tr>
          <td>
            <button type="submit" value='<?php echo $current->id; ?>' name ="id" >
                <?php echo $current->name; ?>
            </button>
          </td>
        </tr>
        <br>
      </form>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
