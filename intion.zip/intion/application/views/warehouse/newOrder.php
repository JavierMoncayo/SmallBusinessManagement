<form method = "post" action="saveNewOrder">
  <table border="0">
    <thead>
      <tr>
        <th><strong><?php echo $output["query"][0]->name; ?> </strong></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Number of units:</td>
        <td><strong><input type="number" step="1" min ='1' name="nUnits"></strong></td>
      </tr>
      <tr>
        <td>€/ud:</td>
        <td><strong><input type="number" step="0.01" min ='0' name="priceIn"></strong><br></td>
      </tr>
      <tr>
        <td>Date in</td>
        <td><strong><input type="date" name="dateIn" value ="<?php echo date('Y-m-d'); ?>"></strong></td>
      </tr>
    </tbody>
  </table>
  <button type="submit" value='<?php echo $output["id"]; ?>' name ="id" >SAVE</button>
</form>