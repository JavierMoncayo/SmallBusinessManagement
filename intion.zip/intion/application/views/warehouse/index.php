<head>
  <script type="text/javascript">
    function getProductId(idProduct)
    {
        $.ajax({
            type: 'POST',
            url: '/intion/index.php/Warehouse/setNewOrder', //the method in controller
            data: 'idProduct=' + idProduct,
            success: function (resp)
            {
                $('#middle1').html(resp);
            }
        });
    }
  </script>
</head>
<div id="left">
  <!--<form method = "post" action="setNewOrder">-->
  <table border="0">
    <caption> Seleccionar producto</caption>
    <thead>
      <tr>
        <th></th>
        <th>Producto</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($output as $current): ?>
          <?php if ($current->id_category == 2): ?>
          <tr onclick="getProductId(<?php echo $current->id ?>)">
            <td>
              <img src="../../images/orderNow.jpg" width = "30" height = "30">
            </td>
            <td>
                <?php echo $current->name; ?>
            </td>
          </tr> 
        <?php endif; ?>
        <?php if ($current->id_category != 2): ?>
          <tr onclick="getProductId(<?php echo $current->id ?>)">
            <td>
              <img src="../../images/orderNow.jpg" width = "30" height = "30">
            </td>
            <td>
                <?php echo $current->name; ?>
            </td>
          </tr> 
        <?php endif; ?>
      <?php endforeach; ?>
    </tbody>
  </table>
  <!--</form>-->
</div>
<div id="middle1">
</div>



