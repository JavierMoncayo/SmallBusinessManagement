<div class="body">
  <ul>
    <li> Add new 
      <ul>
        <li><a class="active" href='<?php echo site_url('inputs/productInput') ?>'>Add new product</a></li>
        <li><a class="active" href='<?php echo site_url('Inputs/categoryInput') ?>'>Add new category</a></li>
        <li><a class="active" href='<?php echo site_url('inputs/familyInput') ?>'>Add new family</a></li>
        <li><a class="active" href='<?php echo site_url('inputs/customerInput') ?>'>Add new customer</a></li>
      </ul>
    </li>
    <li><a class="active" href='<?php echo site_url('Warehouse/index') ?>'>New order</a></li>
    <li><a class="active" href='<?php echo site_url('Deliveries/index') ?>'>New delivery</a></li>
  </ul>
</div>