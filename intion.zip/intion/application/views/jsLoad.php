<?php

//$jsc = $this->config->item('i_JsConfig');
//(var_dump($jsc));
foreach ($jsc as $current)
{
  if ($current)
  {
    echo "<script type='text/javascript' charset='utf-8' src='$js_path$current.js'></script>";
  }
}