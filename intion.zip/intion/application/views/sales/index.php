<head>
    <script type="text/javascript">
        function getStock(idCustomer)
        {
            $.ajax({
                type: 'POST',
                url: '/intion/index.php/Sales/getstockCustomer', //the method in controller
                data: 'idCustomer=' + idCustomer,
                success: function (resp)
                {
                    $('#center').html(resp);
                }
            });
        }
        function deactivateCustomer(idCustomer)
        {
            if (confirm("Confirmar desactivar cliente:"))
            {
                $.ajax({
                    type: 'POST',
                    url: '/intion/index.php/Sales/deactivateCustomer', //the method in controller
                    data: 'idCustomer=' + idCustomer,
                    success: function (resp)
                    {
                        $('#left').html(resp);
                    }
                });
            }
        }
    </script>
</head>

<!--<form method="post" action="getStockCustomer">-->
<div id="myContainer">
    <div id="left">
        <table border="0">
            <thead>
                <tr>
                    <th>Seleccionar cliente</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customer as $current): ?>
                    <tr>
                        <td>
                            <?php echo $current->name ?>
                        </td>
                        <td onclick="" onmouseover="" style="cursor: pointer;">
                            <img src="../../images/delivery.png" 
                                 width = "25" height = "20" 
                                 value="<?php echo $current->id ?>" 
                                 onclick="">
                        </td>
                        <td onclick="getStock(<?php echo $current->id ?>)" onmouseover="" style="cursor: pointer;">
                            <img src="../../images/sale.jpg" 
                                 width = "25" height = "20" 
                                 value="<?php echo $current->id ?>" 
                                 onclick="getStock(<?php echo $current->id ?>)">
                        </td>

                        <td onmouseover="" style="cursor: pointer;">
                            <img src="../../images/explore.png" 
                                 width = "25" height = "20" 
                                 alt = "deactivateCustomer"
                                 value="<?php echo $current->id ?>" 
                                 onclick="">
                        </td>
                        <td></td>
                        <td>
                            <img src="../../images/deactivateCustomer.png" 
                                 width = "25" height = "20" 
                                 alt = "deactivateCustomer"
                                 value="<?php echo $current->id ?>" 
                                 onclick="deactivateCustomer(<?php echo $current->id ?>)">
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>      
        </table>
    </div>
    <!--</form>-->
    <div id="center">

    </div>
</div>
