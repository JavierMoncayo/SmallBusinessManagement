<script>
  function SwapState(chkBox, NumberUds)
  {
      document.getElementById(NumberUds).disabled = !document.getElementById(chkBox).checked;
  }
</script>
<h3><?php echo $customer[0]->name;?></h3>
<div id="middle1">
    <table border="0">
      <thead>
        <tr>
          <th></th>
          <th></th>
          <th>Seleccionar productos</th>
        </tr>
      </thead>
      <tbody>
          <?php
          foreach ($products as $current):

            if ($current->stock == 0)
            {
              $check = "disabled";
              $color = "bgcolor='#e6e6e6'";
            } else
            {
              $check = "enabled";
              $color = "bgcolor='#FFFFFF'";
            }
            ?>
          <tr <?php echo $color ?>>
            <td>
              <input type="checkbox" name="products[]" 
                     value="<?php echo $current->id_product ?>" <?php echo $check ?>
                     id ='<?php echo $current->id_product ?>'
                     onchange="SwapState('<?php echo $current->id_product ?>', '<?php echo ($current->id_product . 'U') ?>')"
                     > 
            </td>
            <td>
              <input style="width: 35px;" type="number" 
                     step="1" min ="1" max="<?php echo $current->stock ?>"
                     id ="<?php echo ($current->id_product . 'U') ?>"
                     name="numberUds[]" value="1" disabled>
            </td>
            <td>
              <?php echo $current->name ?>  (<?php echo $current->stock ?>)
            </td>
            <td>
              <input type="number" step="0.10" name ="prices[]" value ='7' style="width: 35px;"
                     id ="<?php echo ($current->id . 'U') ?>" required disabled>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div id="middle2">
    <input type="date" name="dateDelivery" required value="<?php echo date('Y-m-d'); ?>">
    <br><br><br>
    <button type="submit" value='sale/setDirectSale' name ="id" >Nueva entrega</button>
  </div>