<head>
  <script type="text/javascript">
    function SwapState(chkBox, prices, numberUds, rowProduct)
    {
        document.getElementById(prices).disabled = !document.getElementById(chkBox).checked;
        document.getElementById(numberUds).disabled = !document.getElementById(chkBox).checked;
        row = document.getElementById(rowProduct);
        if (!document.getElementById(chkBox).checked) {
            row.style.backgroundColor = "#dddddd";
        } else
        {
            row.style.backgroundColor = "white";
        }

    }

    function returnProduct(idProduct, idCustomer)
    {
        if (confirm("Devolucion del producto? =("))
        {
            $.ajax({
                type: 'POST',
                url: '/intion/index.php/sales/returnProduct', //the method in controller
                data: 'idProduct=' + idProduct + '&idCustomer=' + idCustomer,
                success: function (resp)
                {
                    $('#center').html(resp);
                }
            });
        }
    }
  </script>
</head>

<form method="post" action="setSale">
  <input type='hidden' name ="customerName" value ='<?php echo $customer->name; ?>'>
  <strong><?php echo $customer->name; ?> </strong>
  <br>
  <br>
  <input type="date" name ="date_sale" value ="<?php echo date('Y-m-d'); ?>">
  <br>
  <br>
  <button type="submit" value='' name ="id" >Confirmar venta</button>
  <div id='center '>
    <table border="0">
      <thead>
        <tr>  
          <th></th>
          <th>Producto</th>
          <th>Uds</th>
          <th>Fecha de entrega</th>
          <th>Dias</th>
          <th>Precio</th>
          <th>Dev</th>
        </tr>
      </thead>
      <tbody>
          <?php foreach ($stock as $current): ?>
          <tr id ="<?php echo ($current->id_product . 'rowProduct') ?>">
            <td onmouseover="" style="cursor: pointer;">
              <input type="checkbox" name="products[]" checked
                     value="<?php echo $current->id_product ?>" 
                     id = "<?php echo $current->id_product ?>"
                     onclick="SwapState('<?php echo $current->id_product ?>',
                                     '<?php echo ($current->id_product . 'prices') ?>',
                                     '<?php echo ($current->id_product . 'numberUds') ?>',
                                     '<?php echo ($current->id_product . 'rowProduct') ?>')"> 
            </td>
            <td>
              <strong>
                  <?php echo $current->name ?>  
              </strong>
            </td>
            <td>
              <strong>
                <input type="number" step ="1" 
                       value ="<?php echo $current->numberUds ?>" style="width: 35px;"
                       id ="<?php echo ($current->id_product . 'numberUds') ?>"
                       name ="numberUds[]">
              </strong>
            </td>
            <td>
                <?php echo $current->date_delivery ?>  
            </td>
            <td>
                <?php echo date('m-d'); ?>  
            </td>
            <td>
              <input type="number" step="0.10" name ="prices[]" value ='7' style="width: 35px;"
                     id ="<?php echo ($current->id_product . 'prices') ?>" >
            </td>
            <td bgcolor="#ff5335" >
              <img src="../../images/productReturn.png" 
                   width = "25" height = "20" 
                   alt = "deactivateCustomer"
                   value="<?php echo $current->id ?>" 
                   onclick="returnProduct('<?php echo $current->id; ?>',
                                   '<?php echo $idCustomer; ?>')"
                   >
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>   
</form>
