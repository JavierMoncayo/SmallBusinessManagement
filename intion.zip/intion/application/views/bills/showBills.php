<div id="left" >    
  <table border="0">
    <thead>
    <caption>Resumen ventas</caption>
    <tr>
      <th>Total uds.</th>
      <th>Coste</th>
      <th>€ brutos</th>
      <th>€ netos</th>
    </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo $salesSummary->totalUnits ?></td>
        <td><?php echo $salesSummary->priceCost ?></td>
        <td><?php echo $salesSummary->priceSale ?></td>
        <td><?php echo $salesSummary->benefits ?></td>
      </tr>
    </tbody>
  </table>
  <br>
  <table border="0">
    <thead>
    <caption>Resumen stock</caption>
    <tr>
      <th>Total Stock</th>
      <th>€</th>
      <th>Casa</th>
      <th>€</th>
      <th>Clientes</th>
      <th>€</th>
    </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo $totalStock->totalUnits ?></td>
        <td><?php echo $totalStock->totalCost ?></td>
        <td><?php echo ($totalStock->totalUnits - $deliveredStock->totalUnits) ?></td>
        <td><?php echo ($totalStock->totalCost - $deliveredStock->totalCost) ?></td>
        <td><?php echo $deliveredStock->totalUnits ?></td>
        <td><?php echo $deliveredStock->totalCost ?></td>

      </tr>
    </tbody>
  </table>
</div>
<div id="middle1">
  <table border="0">
    <caption>Resumen ventas por clientes</caption>
    <thead>
      <tr>
        <th>Cliente</th>
        <th>Tiempo</th>
        <th>Coste</th>
        <th>Brutos</th>
        <th>Netos</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($customerSummary as $current): ?>
        <tr>
          <td>
              <?php echo $current->name ?>
          </td>
          <td>
              <?php echo $current->time ?>
          </td>
          <td>
              <?php echo $current->costs ?>
          </td>
          <td>
              <?php echo $current->sales ?>
          </td>
          <td>
              <?php echo ($current->sales - $current->costs); ?>
          </td>

        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <br>
</div>
<div id="middle2">
  <table border="0">
    <caption>Resumen ventas por productos</caption>
    <thead>
      <tr>
        <th>Modelo</th>
        <th>Uds</th>
        <th>Coste</th>
        <th>Brutos</th>
        <th>Netos</th>
      </tr>
    </thead>
    <tbody>
        <?php foreach ($productsSummary as $current): ?>
        <tr>
          <td>
              <?php echo $current->name; ?>
          </td>
          <td>
              <?php echo $current->unitsSold; ?>
          </td>
          <td>
              <?php echo $current->costs; ?>
          </td>
          <td>
              <?php echo $current->sales; ?>
          </td>
          <td>
              <?php echo $current->sales - $current->costs; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<div id="right">
  Aqui debe aparecer un resumen de lo que tiene repartido cada uno de los clientes
</div>