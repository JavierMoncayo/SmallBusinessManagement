<head>
  <script type="text/javascript">
    function getDates()
    {
        dateStart = document.getElementById('startDate').value;
        dateEnd = document.getElementById('endDate').value;
        $.ajax({
            type: 'POST',
            url: '/intion/index.php/Bills/showBills/'+dateStart+'/'+dateEnd, //the method in controller
            success: function (resp)
            {
                $('#containerDetails').html(resp)
            }
        });
    }
  </script>
</head>

<div id="container">
  <br>
  <div id="mainSubMenu">
    Fecha inicial: 
    <input type="date" id="startDate" required value="<?php echo date('Y-m-d', strtotime('-1 month')); ?>" autofocus="TRUE" >
    Fecha final: 
    <input type="date" id="endDate" required value="<?php echo (date('Y-m-d')) ?>">
    &nbsp;&nbsp;&nbsp;&nbsp;
    <button type="button" value='' name ="id" onclick="getDates()">Comprobar fechas</button>
  </div>  
  <br>  
</div>
<div id="containerDetails">
</div>