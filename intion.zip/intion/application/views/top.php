<html>
  <head>
    <script src="http://127.0.0.1/intion/assets/js/jquery-1.11.1.js"></script>
    <script src="http://127.0.0.1/intion/assets/js/jqueryui.js"></script>
    <script src="http://127.0.0.1/intion/assets/I_menu/menu.js"></script>
    <link rel="stylesheet" type="text/css" href="http://127.0.0.1/intion/assets/I_menu/menu.css">
  </head>
  <body>
    <div id="code">
      <h1>Welcome to Intion &#174 group website!</h1>	
    </div>
    <div id='cssmenu'>
      <ul>        
        <li class='has-sub '><a class="active" >Altas</a>
          <ul>
            <li class='active'>
              <a class="active" href='<?php echo site_url('inputs/productInput') ?>'>Productos</a>
            </li>
            <li class='active'>
              <a class="active" href='<?php echo site_url('Inputs/categoryInput') ?>'>Categorias</a>
            </li>
            <li class='active'>
              <a class="active" href='<?php echo site_url('inputs/familyInput') ?>'>Familias</a>
            </li>
            <li class='active'>
              <a class="active" href='<?php echo site_url('inputs/customerInput') ?>'>Clientes</a>
            </li>
          </ul>
        </li>
        <li><a class="active" href='<?php echo site_url('Warehouse/index') ?>'>Nuevo pedido</a></li>
        <li><a class="active" href='<?php echo site_url('Deliveries/index') ?>'>Nueva Entrega</a></li>
        <li class='has-sub '><a class="active" >Ventas</a>
          <ul>
            <li class='active'>
              <a class="active" href='<?php echo site_url('Sales/index') ?>'>Nueva Venta</a>
            </li>
            <li class='active'>
              <a class="active" href='<?php echo site_url('Sales/directSale') ?>'>Venta Directa</a>
            </li>
          </ul>
        </li>
        <li><a class="active" href='<?php echo site_url('Bills/index') ?>'>Cuentas</a></li>
        <li><a class="active" href='<?php echo site_url('Uploads/index') ?>'>Subir archivos</a></li>

      </ul>
    </div>

<!--    <div id="sse1">
      <div id="sses1">
        <ul>
          <li><a href="?menu=1&skin=2&p=Javascript-Menus">Javascript Menus</a></li>
          <li><a href="?menu=1&skin=2&p=Horizontal-Menus">Horizontal Menus</a></li>
          <li><a href="?menu=1&skin=2&p=Web-Menus">Web Menus</a></li>
        </ul>
      </div>
    </div>-->