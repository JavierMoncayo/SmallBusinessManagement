<div id="left">
    <table border="0">
        <thead>
            <tr>
                <th>Familia</th>
                <th>Nº</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                    var_dump($output);die;?>
            <?php foreach($data->familias as $current): ?>
            <tr>
                <td> 
                    
                    
                    echo $current->familia; ?>
                </td>
                <td>
                    <?php echo $current->units; ?>
                </td>
            </tr>
            <?php endforeach;?>
        </tbody>
    </table>
</div>